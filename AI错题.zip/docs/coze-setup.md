# Coze 接入流程

这个项目推荐在 Coze 中使用 **Workflow** 来处理拍照错题，因为图片识别、错因诊断和结构化输出更适合工作流。

## 1. 创建 Workflow

名称建议：

```text
初中数学错题拍照分析工作流
```

输入参数建议：

```text
question_image    Image/File 类型，必填
student_note      Text 类型，选填
grade             Text 类型，默认：初中
unit              Text 类型，默认：一次函数
```

## 2. 工作流节点

建议按这个顺序搭：

```text
开始节点
-> 图片识别节点
-> 题目与解题痕迹整理节点
-> 错因诊断节点
-> 追问生成节点
-> 订正卡生成节点
-> 结束节点
```

如果 Coze 里可直接使用多模态大模型节点，可以把“图片识别”和“整理”合并到一个大模型节点。

## 3. 大模型节点提示词

可以先使用这个版本：

```text
你是面向初中生的数学错题追问式AI学伴。

请根据上传的错题图片和学生补充说明，识别并分析：
1. 题目内容
2. 学生书写的解题过程
3. 涉及的数学知识点
4. 可能的错因

你不能直接给完整答案。
你需要输出一个追问，引导学生自己发现错误。
如果图片不清楚，请提示重新拍照。
语言要适合初中生，简洁、亲切、具体。

请严格输出 JSON，不要输出 Markdown。
```

## 4. 输出格式

结束节点建议固定输出 JSON：

```json
{
  "questionText": "识别出的题目",
  "studentWorkText": "识别出的学生解题过程",
  "knowledgePoint": "一次函数",
  "errorTag": "计算错误",
  "analysis": "学生可能把 x 的值代入位置弄错了。",
  "firstQuestion": "你能先说说 x=3 应该代入到表达式的哪个位置吗？",
  "correctionCard": {
    "title": "错题订正卡",
    "correctThinking": "先确定函数表达式，再代入 x 的值。",
    "tip": "不要把 x 的值直接加到常数项后面。",
    "nextPractice": "已知 y=3x-2，求 x=4 时 y 的值。"
  }
}
```

项目后端会优先读取这些字段：

```text
questionText
studentWorkText
knowledgePoint
errorTag
analysis
firstQuestion
correctionCard.tip
correctionCard.nextPractice
```

## 5. 发布 API 并填写本地配置

发布 Workflow 后，准备：

```text
COZE_API_TOKEN
COZE_WORKFLOW_ID
```

复制配置文件：

```bash
cd server
copy .env.example .env
```

编辑 `server/.env`：

```text
PORT=3000
TUTOR_UNIT_NAME=一次函数
COZE_API_BASE_URL=https://api.coze.cn
COZE_API_TOKEN=你的Coze API Token
COZE_WORKFLOW_ID=你的Workflow ID
```

如果你还想保留文字追问接口，也可以额外填写：

```text
COZE_BOT_ID=你的Bot ID
```

## 6. 本地验证

启动后端：

```bash
cd server
npm run dev
```

访问：

```text
http://127.0.0.1:3000/api/health
```

如果返回：

```json
{
  "ok": true,
  "aiMode": "coze",
  "service": "ai-math-tutor"
}
```

说明后端已经读取到 Coze 配置。

## 7. 注意事项

- Coze Token 只放在 `server/.env`，不要写进小程序前端。
- 小程序本地拍到的图片会先转成 Base64 发给本地后端。
- 后端再上传图片到 Coze 文件接口，并把得到的 `file_id` 传给 Workflow。
- 不配置 Coze 时，项目会使用本地模拟结果，适合先演示页面流程。

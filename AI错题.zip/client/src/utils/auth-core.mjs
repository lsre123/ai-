export function createLocalAuthUser({
  userInfo = {},
  loginResult = {},
  now = () => new Date(),
  random = Math.random
} = {}) {
  const nickname = userInfo.nickName || userInfo.nickname || '本地演示用户'
  const avatarUrl = userInfo.avatarUrl || ''
  const idToken = random().toString(36).slice(2, 8).padEnd(6, '0')

  return {
    id: `local-weixin-${idToken}`,
    nickName: nickname,
    avatarUrl,
    provider: 'weixin',
    loginCode: loginResult.code || '',
    loginAt: now().toISOString()
  }
}

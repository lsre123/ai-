const CARDS_KEY = 'ai_math_tutor_cards'
const CURRENT_CARD_KEY = 'ai_math_tutor_current_card'
const REVIEW_DONE_KEY = 'ai_math_tutor_review_done'

export function getCards() {
  return uni.getStorageSync(CARDS_KEY) || []
}

export function saveCard(card) {
  const saved = {
    ...card,
    id: card.id || card.cardId || `${Date.now()}`,
    createdAt: card.createdAt || new Date().toISOString()
  }
  const cards = [saved, ...getCards()].slice(0, 30)
  uni.setStorageSync(CARDS_KEY, cards)
  return saved
}

export function clearCards() {
  uni.removeStorageSync(CARDS_KEY)
}

export function setCurrentCard(card) {
  uni.setStorageSync(CURRENT_CARD_KEY, card)
}

export function getCurrentCard() {
  return uni.getStorageSync(CURRENT_CARD_KEY) || null
}

function countBy(items, getter) {
  const map = {}
  items.forEach((item) => {
    const key = getter(item)
    if (!key) return
    map[key] = (map[key] || 0) + 1
  })

  return Object.keys(map)
    .map((name) => ({ name, count: map[name] }))
    .sort((a, b) => b.count - a.count)
}

function getBreakpoint(card) {
  if (card.breakpoint) return card.breakpoint
  const tag = card.errorTag || ''
  if (tag.includes('条件') || tag.includes('审题') || tag.includes('遗漏')) return '条件提取断点'
  if (tag.includes('图像') || tag.includes('坐标') || tag.includes('读图')) return '读图断点'
  if (tag.includes('公式') || tag.includes('建模') || tag.includes('表达式')) return '建模断点'
  if (tag.includes('计算') || tag.includes('代入') || tag.includes('运算')) return '运算断点'
  if (tag.includes('检验')) return '检验断点'
  return '表达断点'
}

function addDays(date, days) {
  const next = new Date(date)
  next.setDate(next.getDate() + days)
  return next
}

function formatDate(date) {
  const year = date.getFullYear()
  const month = `${date.getMonth() + 1}`.padStart(2, '0')
  const day = `${date.getDate()}`.padStart(2, '0')
  return `${year}-${month}-${day}`
}

export function getProfileStats() {
  const cards = getCards()

  return {
    totalCards: cards.length,
    topBreakpoints: countBy(cards, getBreakpoint).slice(0, 5),
    topKnowledgePoints: countBy(cards, (card) => card.knowledgePoint).slice(0, 5),
    topErrors: countBy(cards, (card) => card.errorTag).slice(0, 5),
    recentCards: cards.slice(0, 5)
  }
}

export function getReviewTasks() {
  const doneMap = uni.getStorageSync(REVIEW_DONE_KEY) || {}

  return getCards().map((card) => {
    const createdAt = card.createdAt ? new Date(String(card.createdAt).replace(/-/g, '/')) : new Date()
    const reviewAt = card.nextReviewAt || formatDate(addDays(createdAt, 1))
    const id = card.cardId || card.id

    return {
      id,
      card,
      reviewAt,
      done: Boolean(doneMap[id])
    }
  })
}

export function markReviewDone(taskId) {
  const doneMap = uni.getStorageSync(REVIEW_DONE_KEY) || {}
  doneMap[taskId] = new Date().toISOString()
  uni.setStorageSync(REVIEW_DONE_KEY, doneMap)
}

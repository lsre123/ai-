import { createLocalAuthUser } from './auth-core.mjs'

const AUTH_USER_KEY = 'ai_math_tutor_auth_user'

export function getAuthUser() {
  try {
    const user = uni.getStorageSync(AUTH_USER_KEY)
    return user && user.id ? user : null
  } catch (error) {
    return null
  }
}

export function saveAuthUser(profile = {}, loginResult = {}) {
  const user = createLocalAuthUser({
    userInfo: profile.userInfo || profile,
    loginResult
  })
  uni.setStorageSync(AUTH_USER_KEY, user)
  return user
}

export function saveDemoAuthUser() {
  const user = createLocalAuthUser({
    userInfo: {
      nickName: '本地演示用户',
      avatarUrl: ''
    },
    loginResult: {}
  })
  uni.setStorageSync(AUTH_USER_KEY, user)
  return user
}

export function clearAuthUser() {
  uni.removeStorageSync(AUTH_USER_KEY)
}

export function requireLogin() {
  if (getAuthUser()) return true

  uni.reLaunch({
    url: '/pages/login/login'
  })
  return false
}

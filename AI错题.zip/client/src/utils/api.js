import { API_BASE_URL } from '../config'

function request({ url, method = 'GET', data }) {
  return new Promise((resolve, reject) => {
    uni.request({
      url: `${API_BASE_URL}${url}`,
      method,
      data,
      header: {
        'Content-Type': 'application/json'
      },
      success(response) {
        if (response.statusCode >= 200 && response.statusCode < 300) {
          resolve(response.data)
        } else {
          reject(new Error(response.data?.hint || response.data?.error || 'Request failed'))
        }
      },
      fail(error) {
        reject(error)
      }
    })
  })
}

export function getHealth() {
  return request({ url: '/api/health' })
}

export function chatWithTutor(payload) {
  return request({
    url: '/api/chat',
    method: 'POST',
    data: payload
  })
}

export function solvePhoto(payload) {
  return new Promise((resolve, reject) => {
    uni.uploadFile({
      url: `${API_BASE_URL}/api/photo-solve-upload`,
      filePath: payload.filePath,
      name: 'question_image',
      formData: {
        studentNote: payload.studentNote || '',
        unit: payload.unit || '一次函数'
      },
      success(response) {
        let data = response.data
        if (typeof data === 'string') {
          try {
            data = JSON.parse(data)
          } catch (error) {
            reject(new Error(data || '图片分析失败'))
            return
          }
        }

        if (response.statusCode >= 200 && response.statusCode < 300) {
          resolve(data)
        } else {
          reject(new Error(data?.hint || data?.error || '图片分析失败'))
        }
      },
      fail(error) {
        reject(new Error(error.errMsg || error.message || '图片上传失败'))
      }
    })
  })
}

export function followUpTutor(payload) {
  return request({
    url: '/api/follow-up',
    method: 'POST',
    data: payload
  })
}

export function generateDiagnosis(payload) {
  return request({
    url: '/api/diagnosis',
    method: 'POST',
    data: payload
  })
}

export function generateCorrectionCard(payload) {
  return request({
    url: '/api/correction-card',
    method: 'POST',
    data: payload
  })
}

export function generateVariantQuestion(payload) {
  return request({
    url: '/api/variant-question',
    method: 'POST',
    data: payload
  })
}

export function getProfile(userId = 'demo_user') {
  return request({ url: `/api/profile?userId=${encodeURIComponent(userId)}` })
}

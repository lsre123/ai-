<script>
export default {
  onLaunch: function () {
    console.log('AI Math Tutor Launch')
  },
  onShow: function () {
    console.log('AI Math Tutor Show')
  },
  onHide: function () {
    console.log('AI Math Tutor Hide')
  },
}
</script>

<style>
page {
  background: #f5f1e8;
}
</style>

<template>
  <view class="page">
    <view class="hero">
      <view class="hero-copy">
        <text class="eyebrow">初中数学 · 追问式订正</text>
        <text class="title">错题不急着看答案</text>
        <text class="summary">先说思路，再找错因。AI 每次只给一个追问或提示，帮助学生把订正写明白。</text>
      </view>
      <view class="board">
        <view class="axis x-axis"></view>
        <view class="axis y-axis"></view>
        <view class="line"></view>
        <view class="point point-a"></view>
        <view class="point point-b"></view>
      </view>
    </view>

    <view class="user-panel">
      <view class="user-main">
        <image v-if="avatarUrl" class="avatar" :src="avatarUrl" mode="aspectFill"></image>
        <view v-else class="avatar avatar-fallback">
          <text>{{ userInitial }}</text>
        </view>
        <view>
          <text class="panel-label">当前学生</text>
          <text class="panel-value">{{ nickName }}</text>
        </view>
      </view>
      <button class="ghost-button" size="mini" @tap="handleLogout">退出</button>
    </view>

    <view class="status-panel">
      <view>
        <text class="panel-label">本地服务</text>
        <text class="panel-value">{{ healthText }}</text>
      </view>
      <button class="ghost-button" size="mini" @tap="checkHealth">刷新</button>
    </view>

    <view class="actions">
      <button class="primary-button" @tap="startTutor">开始错题订正</button>
      <button class="secondary-button" @tap="openHistory">查看历史记录</button>
    </view>

    <view class="quick-grid">
      <button class="quick-button" @tap="openProfile">错法画像</button>
      <button class="quick-button" @tap="openReview">复习任务</button>
    </view>

    <view class="section">
      <view class="section-head">
        <text class="section-title">最近订正</text>
        <text class="section-meta">{{ recentCards.length }} 条</text>
      </view>

      <view v-if="recentCards.length === 0" class="empty">
        <text>还没有订正卡。先完成一次错题对话，这里会自动保存本地记录。</text>
      </view>

      <view
        v-for="card in recentCards"
        :key="card.id"
        class="history-item"
        @tap="openCard(card)"
      >
        <text class="history-title">{{ card.knowledgePoint }} · {{ card.errorTag }}</text>
        <text class="history-question">{{ card.question || '未填写题干' }}</text>
      </view>
    </view>
  </view>
</template>

<script setup>
import { computed, ref } from 'vue'
import { onShow } from '@dcloudio/uni-app'

import { getHealth } from '../../utils/api'
import { clearAuthUser, getAuthUser, requireLogin } from '../../utils/auth'
import { getCards, setCurrentCard } from '../../utils/storage'

const health = ref(null)
const recentCards = ref([])
const user = ref(null)

const healthText = computed(() => {
  if (!health.value) return '未连接'
  return health.value.aiMode === 'coze' ? 'Coze 已接入' : '本地模拟模式'
})

const nickName = computed(() => user.value?.nickName || '本地演示用户')

const avatarUrl = computed(() => user.value?.avatarUrl || '')

const userInitial = computed(() => {
  const name = nickName.value || '本'
  return name.slice(0, 1)
})

function refreshCards() {
  recentCards.value = getCards().slice(0, 3)
}

async function checkHealth() {
  try {
    health.value = await getHealth()
  } catch (error) {
    health.value = null
    uni.showToast({
      title: '请先启动本地后端',
      icon: 'none'
    })
  }
}

function startTutor() {
  uni.navigateTo({ url: '/pages/tutor/tutor' })
}

function openHistory() {
  uni.navigateTo({ url: '/pages/history/history' })
}

function openProfile() {
  uni.navigateTo({ url: '/pages/profile/profile' })
}

function openReview() {
  uni.navigateTo({ url: '/pages/review/review' })
}

function openCard(card) {
  setCurrentCard(card)
  uni.navigateTo({ url: '/pages/card/card' })
}

function handleLogout() {
  uni.showModal({
    title: '退出登录',
    content: '退出后可以重新使用微信授权登录。',
    success(result) {
      if (!result.confirm) return

      clearAuthUser()
      uni.reLaunch({
        url: '/pages/login/login'
      })
    }
  })
}

onShow(() => {
  if (!requireLogin()) return

  user.value = getAuthUser()
  refreshCards()
  checkHealth()
})
</script>

<style>
.page {
  min-height: 100vh;
  padding: 32rpx;
  background: #f5f1e8;
  color: #17211a;
  box-sizing: border-box;
}

.hero {
  display: flex;
  gap: 28rpx;
  align-items: stretch;
  padding: 34rpx;
  border: 2rpx solid #17211a;
  border-radius: 8rpx;
  background: #fffbef;
  box-shadow: 10rpx 10rpx 0 #17211a;
}

.hero-copy {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 14rpx;
}

.eyebrow {
  font-size: 23rpx;
  color: #5b6b57;
}

.title {
  font-size: 48rpx;
  line-height: 1.12;
  font-weight: 700;
}

.summary {
  font-size: 27rpx;
  line-height: 1.65;
  color: #495243;
}

.board {
  position: relative;
  width: 190rpx;
  min-height: 210rpx;
  border-radius: 6rpx;
  background:
    linear-gradient(#d8d0bd 1rpx, transparent 1rpx),
    linear-gradient(90deg, #d8d0bd 1rpx, transparent 1rpx),
    #f4ead2;
  background-size: 34rpx 34rpx;
  border: 2rpx solid #17211a;
  overflow: hidden;
}

.axis {
  position: absolute;
  background: #17211a;
}

.x-axis {
  left: 18rpx;
  right: 12rpx;
  bottom: 54rpx;
  height: 3rpx;
}

.y-axis {
  left: 48rpx;
  top: 18rpx;
  bottom: 20rpx;
  width: 3rpx;
}

.line {
  position: absolute;
  left: 24rpx;
  top: 100rpx;
  width: 178rpx;
  height: 4rpx;
  background: #2f7d63;
  transform: rotate(-28deg);
  transform-origin: left center;
}

.point {
  position: absolute;
  width: 16rpx;
  height: 16rpx;
  border-radius: 50%;
  background: #c84d2f;
  border: 2rpx solid #17211a;
}

.point-a {
  left: 66rpx;
  top: 98rpx;
}

.point-b {
  right: 34rpx;
  top: 56rpx;
}

.user-panel,
.status-panel,
.section {
  margin-top: 34rpx;
  padding: 28rpx;
  border: 2rpx solid #17211a;
  border-radius: 8rpx;
  background: #fffaf0;
}

.user-panel,
.status-panel {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.user-main {
  display: flex;
  min-width: 0;
  align-items: center;
  gap: 18rpx;
}

.avatar {
  width: 78rpx;
  height: 78rpx;
  flex: 0 0 78rpx;
  border: 2rpx solid #17211a;
  border-radius: 50%;
  background: #efe6d4;
}

.avatar-fallback {
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f2cf5b;
  font-size: 30rpx;
  font-weight: 700;
}

.panel-label,
.section-meta {
  display: block;
  font-size: 23rpx;
  color: #66705f;
}

.panel-value {
  display: block;
  margin-top: 6rpx;
  font-size: 31rpx;
  font-weight: 700;
}

.actions {
  display: flex;
  gap: 18rpx;
  margin-top: 34rpx;
}

.quick-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 14rpx;
  margin-top: 18rpx;
}

button {
  margin: 0;
  border-radius: 8rpx;
}

button::after {
  border: 0;
}

.primary-button,
.secondary-button,
.ghost-button,
.quick-button {
  height: 88rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 29rpx;
  border: 2rpx solid #17211a;
}

.primary-button {
  flex: 1.2;
  color: #fffaf0;
  background: #1f6b55;
}

.secondary-button {
  flex: 1;
  color: #17211a;
  background: #f2cf5b;
}

.ghost-button {
  height: 64rpx;
  padding: 0 24rpx;
  color: #17211a;
  background: #fffaf0;
}

.quick-button {
  height: 76rpx;
  color: #17211a;
  background: #fffaf0;
  font-size: 25rpx;
}

.section-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 22rpx;
}

.section-title {
  font-size: 34rpx;
  font-weight: 700;
}

.empty {
  padding: 28rpx;
  border-radius: 6rpx;
  background: #efe6d4;
  font-size: 27rpx;
  line-height: 1.6;
  color: #5b6358;
}

.history-item {
  padding: 24rpx 0;
  border-top: 2rpx solid #e1d6bf;
}

.history-item:first-of-type {
  border-top: 0;
}

.history-title {
  display: block;
  font-size: 29rpx;
  font-weight: 700;
}

.history-question {
  display: block;
  margin-top: 10rpx;
  font-size: 25rpx;
  line-height: 1.5;
  color: #5b6358;
}
</style>

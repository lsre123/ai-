<template>
  <view class="page">
    <view class="header">
      <text class="title">错法画像</text>
      <text class="subtitle">看清自己常在哪个思维环节出错。</text>
    </view>

    <view class="summary-panel">
      <view>
        <text class="metric">{{ stats.totalCards }}</text>
        <text class="metric-label">已保存订正卡</text>
      </view>
      <view>
        <text class="metric">{{ stats.topBreakpoints.length }}</text>
        <text class="metric-label">高频断点</text>
      </view>
    </view>

    <view class="section">
      <text class="section-title">高频思维断点</text>
      <view v-if="stats.topBreakpoints.length === 0" class="empty">完成订正后会自动生成画像。</view>
      <view v-for="item in stats.topBreakpoints" :key="item.name" class="rank-row">
        <view class="rank-copy">
          <text class="rank-name">{{ item.name }}</text>
          <text class="rank-count">{{ item.count }} 次</text>
        </view>
        <view class="bar">
          <view class="bar-fill" :style="{ width: barWidth(item.count) }"></view>
        </view>
      </view>
    </view>

    <view class="section">
      <text class="section-title">高频知识点</text>
      <view v-for="item in stats.topKnowledgePoints" :key="item.name" class="pill-row">
        <text>{{ item.name }}</text>
        <text>{{ item.count }} 次</text>
      </view>
    </view>

    <view class="section">
      <text class="section-title">最近订正</text>
      <view v-for="card in stats.recentCards" :key="card.id" class="card-row" @tap="openCard(card)">
        <text class="card-title">{{ card.knowledgePoint }} · {{ card.errorTag }}</text>
        <text class="card-text">{{ card.studentSummary || card.question || '继续补充自己的错因总结' }}</text>
      </view>
    </view>
  </view>
</template>

<script setup>
import { ref } from 'vue'
import { onShow } from '@dcloudio/uni-app'

import { requireLogin } from '../../utils/auth'
import { getProfileStats, setCurrentCard } from '../../utils/storage'

const stats = ref({
  totalCards: 0,
  topBreakpoints: [],
  topKnowledgePoints: [],
  recentCards: []
})

function barWidth(count) {
  const max = stats.value.topBreakpoints[0]?.count || 1
  return `${Math.max(12, Math.round((count / max) * 100))}%`
}

function openCard(card) {
  setCurrentCard(card)
  uni.navigateTo({ url: '/pages/card/card' })
}

onShow(() => {
  if (!requireLogin()) return
  stats.value = getProfileStats()
})
</script>

<style>
.page {
  min-height: 100vh;
  padding: 30rpx;
  background: #f5f1e8;
  color: #17211a;
  box-sizing: border-box;
}

.header {
  padding: 20rpx 0 10rpx;
}

.title {
  display: block;
  font-size: 44rpx;
  font-weight: 700;
}

.subtitle {
  display: block;
  margin-top: 10rpx;
  color: #66705f;
  font-size: 26rpx;
}

.summary-panel,
.section {
  margin-top: 26rpx;
  padding: 28rpx;
  border: 2rpx solid #17211a;
  border-radius: 8rpx;
  background: #fffaf0;
}

.summary-panel {
  display: flex;
  justify-content: space-around;
  text-align: center;
  box-shadow: 8rpx 8rpx 0 #17211a;
}

.metric {
  display: block;
  font-size: 52rpx;
  font-weight: 700;
}

.metric-label,
.rank-count,
.card-text,
.empty {
  color: #66705f;
  font-size: 25rpx;
}

.section-title {
  display: block;
  margin-bottom: 20rpx;
  font-size: 34rpx;
  font-weight: 700;
}

.rank-row,
.pill-row,
.card-row {
  padding: 20rpx 0;
  border-top: 2rpx solid #e1d6bf;
}

.rank-row:first-of-type,
.pill-row:first-of-type,
.card-row:first-of-type {
  border-top: 0;
}

.rank-copy,
.pill-row {
  display: flex;
  justify-content: space-between;
  gap: 20rpx;
}

.rank-name,
.card-title {
  font-size: 29rpx;
  font-weight: 700;
}

.bar {
  height: 18rpx;
  margin-top: 14rpx;
  border: 2rpx solid #17211a;
  border-radius: 8rpx;
  background: #f7edd8;
  overflow: hidden;
}

.bar-fill {
  height: 100%;
  background: #1f6b55;
}

.pill-row {
  font-size: 28rpx;
}

.card-title,
.card-text {
  display: block;
}

.card-text {
  margin-top: 8rpx;
  line-height: 1.5;
}
</style>

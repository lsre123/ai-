<template>
  <view class="page">
    <view class="brand-panel">
      <view class="badge">
        <text>AI</text>
      </view>
      <text class="eyebrow">初中数学错题追问</text>
      <text class="title">先注册/登录，再开始你的订正记录</text>
      <text class="summary">
        使用微信授权登录后，错题分析、追问对话和订正卡会保存在本地，方便继续查看。
      </text>
    </view>

    <view class="login-panel">
      <view class="wechat-mark">
        <text>微</text>
      </view>
      <text class="panel-title">微信授权注册/登录</text>
      <text class="panel-text">
        本地演示版只保存头像昵称和登录状态，不会上传你的个人资料。
      </text>

      <button class="wechat-button" :loading="loading" @tap="loginWithWechat">
        微信授权注册/登录
      </button>
      <button class="demo-button" @tap="loginAsDemo">
        本地演示登录
      </button>
    </view>
  </view>
</template>

<script setup>
import { ref } from 'vue'
import { onShow } from '@dcloudio/uni-app'

import { getAuthUser, saveAuthUser, saveDemoAuthUser } from '../../utils/auth'

const loading = ref(false)

function requestUserProfile() {
  return new Promise((resolve, reject) => {
    if (uni.getUserProfile) {
      uni.getUserProfile({
        desc: '用于展示学习记录和订正卡归属',
        success: resolve,
        fail: reject
      })
      return
    }

    if (typeof wx !== 'undefined' && wx.getUserProfile) {
      wx.getUserProfile({
        desc: '用于展示学习记录和订正卡归属',
        success: resolve,
        fail: reject
      })
      return
    }

    reject(new Error('当前环境不支持微信资料授权'))
  })
}

function requestLoginCode() {
  return new Promise((resolve) => {
    uni.login({
      provider: 'weixin',
      success: resolve,
      fail: () => resolve({})
    })
  })
}

function enterHome() {
  uni.reLaunch({
    url: '/pages/index/index'
  })
}

async function loginWithWechat() {
  if (loading.value) return

  loading.value = true
  try {
    const profile = await requestUserProfile()
    const loginResult = await requestLoginCode()
    saveAuthUser(profile, loginResult)
    enterHome()
  } catch (error) {
    uni.showModal({
      title: '授权未完成',
      content: '可以重新点击微信授权登录；如果只是本地演示，也可以先用本地演示登录。',
      showCancel: false
    })
  } finally {
    loading.value = false
  }
}

function loginAsDemo() {
  saveDemoAuthUser()
  enterHome()
}

onShow(() => {
  if (getAuthUser()) enterHome()
})
</script>

<style>
.page {
  min-height: 100vh;
  padding: 42rpx 32rpx;
  background: #f5f1e8;
  color: #17211a;
  box-sizing: border-box;
}

.brand-panel,
.login-panel {
  border: 2rpx solid #17211a;
  border-radius: 8rpx;
  background: #fffaf0;
}

.brand-panel {
  padding: 40rpx 34rpx;
  box-shadow: 10rpx 10rpx 0 #17211a;
}

.badge {
  display: flex;
  width: 84rpx;
  height: 84rpx;
  align-items: center;
  justify-content: center;
  border: 2rpx solid #17211a;
  border-radius: 50%;
  background: #f2cf5b;
  font-size: 31rpx;
  font-weight: 700;
}

.eyebrow,
.summary,
.panel-text {
  display: block;
  color: #66705f;
}

.eyebrow {
  margin-top: 32rpx;
  font-size: 24rpx;
}

.title {
  display: block;
  margin-top: 12rpx;
  font-size: 48rpx;
  line-height: 1.18;
  font-weight: 700;
}

.summary {
  margin-top: 18rpx;
  font-size: 27rpx;
  line-height: 1.65;
}

.login-panel {
  margin-top: 46rpx;
  padding: 34rpx;
}

.wechat-mark {
  display: flex;
  width: 88rpx;
  height: 88rpx;
  align-items: center;
  justify-content: center;
  border: 2rpx solid #17211a;
  border-radius: 8rpx;
  background: #1f8f5f;
  color: #fffaf0;
  font-size: 36rpx;
  font-weight: 700;
}

.panel-title {
  display: block;
  margin-top: 24rpx;
  font-size: 36rpx;
  font-weight: 700;
}

.panel-text {
  margin-top: 12rpx;
  font-size: 26rpx;
  line-height: 1.55;
}

button {
  margin: 0;
  border-radius: 8rpx;
}

button::after {
  border: 0;
}

.wechat-button,
.demo-button {
  display: flex;
  width: 100%;
  height: 88rpx;
  align-items: center;
  justify-content: center;
  border: 2rpx solid #17211a;
  font-size: 30rpx;
}

.wechat-button {
  margin-top: 34rpx;
  background: #1f6b55;
  color: #fffaf0;
}

.demo-button {
  margin-top: 18rpx;
  background: #f2cf5b;
  color: #17211a;
}
</style>

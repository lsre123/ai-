<template>
  <view class="page">
    <view class="header">
      <text class="title">复习任务</text>
      <text class="subtitle">按订正卡自动安排第二天复习。</text>
    </view>

    <view v-if="tasks.length === 0" class="empty">
      <text>还没有复习任务。完成一次错题订正后，这里会出现待复习卡片。</text>
    </view>

    <view v-for="task in tasks" :key="task.id" :class="['task', task.done ? 'done' : '']">
      <view class="task-head">
        <view>
          <text class="task-title">{{ task.card.knowledgePoint }} · {{ task.card.errorTag }}</text>
          <text class="task-date">复习时间：{{ task.reviewAt }}</text>
        </view>
        <text class="badge">{{ task.done ? '已完成' : '待复习' }}</text>
      </view>
      <text class="task-text">{{ task.card.variantQuestion || task.card.nextPractice || task.card.question }}</text>
      <view class="actions">
        <button class="ghost-button" @tap="openCard(task.card)">查看订正卡</button>
        <button v-if="!task.done" class="primary-button" @tap="finishTask(task.id)">完成复习</button>
      </view>
    </view>
  </view>
</template>

<script setup>
import { ref } from 'vue'
import { onShow } from '@dcloudio/uni-app'

import { requireLogin } from '../../utils/auth'
import { getReviewTasks, markReviewDone, setCurrentCard } from '../../utils/storage'

const tasks = ref([])

function loadTasks() {
  if (!requireLogin()) return
  tasks.value = getReviewTasks()
}

function openCard(card) {
  setCurrentCard(card)
  uni.navigateTo({ url: '/pages/card/card' })
}

function finishTask(taskId) {
  markReviewDone(taskId)
  loadTasks()
}

onShow(loadTasks)
</script>

<style>
.page {
  min-height: 100vh;
  padding: 30rpx;
  background: #f5f1e8;
  color: #17211a;
  box-sizing: border-box;
}

.header {
  padding: 20rpx 0 10rpx;
}

.title {
  display: block;
  font-size: 44rpx;
  font-weight: 700;
}

.subtitle,
.task-date,
.task-text,
.empty {
  color: #66705f;
  font-size: 26rpx;
  line-height: 1.5;
}

.subtitle {
  display: block;
  margin-top: 10rpx;
}

.empty,
.task {
  margin-top: 26rpx;
  padding: 28rpx;
  border: 2rpx solid #17211a;
  border-radius: 8rpx;
  background: #fffaf0;
}

.task.done {
  background: #eef2e6;
}

.task-head {
  display: flex;
  justify-content: space-between;
  gap: 18rpx;
}

.task-title,
.task-date,
.task-text {
  display: block;
}

.task-title {
  font-size: 31rpx;
  font-weight: 700;
}

.task-date {
  margin-top: 8rpx;
}

.badge {
  flex: 0 0 auto;
  height: 48rpx;
  padding: 0 16rpx;
  border: 2rpx solid #17211a;
  border-radius: 6rpx;
  background: #f2cf5b;
  line-height: 48rpx;
  font-size: 23rpx;
}

.task-text {
  margin-top: 22rpx;
}

.actions {
  display: flex;
  gap: 16rpx;
  margin-top: 22rpx;
}

button {
  margin: 0;
  border-radius: 8rpx;
}

button::after {
  border: 0;
}

.ghost-button,
.primary-button {
  flex: 1;
  height: 76rpx;
  border: 2rpx solid #17211a;
  font-size: 27rpx;
}

.ghost-button {
  color: #17211a;
  background: #fffaf0;
}

.primary-button {
  color: #fffaf0;
  background: #1f6b55;
}
</style>

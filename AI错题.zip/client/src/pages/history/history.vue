<template>
  <view class="page">
    <view class="header">
      <text class="title">历史订正</text>
      <button v-if="cards.length" class="clear-button" size="mini" @tap="clearAll">清空</button>
    </view>

    <view v-if="cards.length === 0" class="empty">
      <text>本地还没有保存订正卡。</text>
    </view>

    <view
      v-for="card in cards"
      :key="card.id"
      class="item"
      @tap="openCard(card)"
    >
      <view>
        <text class="item-title">{{ card.knowledgePoint }} · {{ card.errorTag }}</text>
        <text class="item-question">{{ card.question || '未填写题干' }}</text>
      </view>
      <text class="item-date">{{ formatDate(card.createdAt) }}</text>
    </view>
  </view>
</template>

<script setup>
import { ref } from 'vue'
import { onShow } from '@dcloudio/uni-app'

import { requireLogin } from '../../utils/auth'
import { clearCards, getCards, setCurrentCard } from '../../utils/storage'

const cards = ref([])

function loadCards() {
  if (!requireLogin()) return

  cards.value = getCards()
}

function openCard(card) {
  setCurrentCard(card)
  uni.navigateTo({ url: '/pages/card/card' })
}

function clearAll() {
  uni.showModal({
    title: '清空历史记录',
    content: '这些记录只保存在本机，清空后不可恢复。',
    success(result) {
      if (result.confirm) {
        clearCards()
        loadCards()
      }
    }
  })
}

function formatDate(value) {
  if (!value) return ''
  const date = new Date(value)
  const month = `${date.getMonth() + 1}`.padStart(2, '0')
  const day = `${date.getDate()}`.padStart(2, '0')
  const hour = `${date.getHours()}`.padStart(2, '0')
  const minute = `${date.getMinutes()}`.padStart(2, '0')
  return `${month}-${day} ${hour}:${minute}`
}

onShow(loadCards)
</script>

<style>
.page {
  min-height: 100vh;
  padding: 30rpx;
  background: #f5f1e8;
  color: #17211a;
  box-sizing: border-box;
}

.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin: 20rpx 0 26rpx;
}

.title {
  font-size: 42rpx;
  font-weight: 700;
}

button {
  margin: 0;
  border-radius: 8rpx;
}

button::after {
  border: 0;
}

.clear-button {
  border: 2rpx solid #17211a;
  color: #17211a;
  background: #fffaf0;
}

.empty,
.item {
  padding: 28rpx;
  border: 2rpx solid #17211a;
  border-radius: 8rpx;
  background: #fffaf0;
}

.empty {
  color: #66705f;
  font-size: 28rpx;
}

.item {
  margin-bottom: 22rpx;
}

.item-title {
  display: block;
  font-size: 30rpx;
  font-weight: 700;
}

.item-question {
  display: block;
  margin-top: 12rpx;
  font-size: 26rpx;
  line-height: 1.5;
  color: #4e574c;
}

.item-date {
  display: block;
  margin-top: 18rpx;
  color: #6b6f67;
  font-size: 24rpx;
}
</style>

<template>
  <view class="page">
    <view class="header">
      <text class="title">拍照分析错题</text>
      <text class="subtitle">拍下题目和你的解题痕迹，AI 会先识别内容，再通过追问帮你完成订正。</text>
    </view>

    <view class="capture-panel">
      <view v-if="imagePath" class="preview-wrap">
        <image class="preview-image" :src="imagePath" mode="aspectFill"></image>
        <button class="mini-button" @tap="clearImage">重拍</button>
      </view>
      <view v-else class="camera-placeholder">
        <view class="camera-icon">
          <view class="lens"></view>
        </view>
        <text class="placeholder-title">先拍一张错题照片</text>
        <text class="placeholder-text">尽量让题干、草稿和答案都在画面里，光线清楚一点。</text>
      </view>

      <view class="capture-actions">
        <button class="primary-button" @tap="chooseImage('camera')">拍照</button>
        <button class="secondary-button" @tap="chooseImage('album')">从相册选</button>
      </view>
    </view>

    <view class="note-panel">
      <text class="label">补充说明</text>
      <textarea
        class="textarea"
        v-model="studentNote"
        placeholder="可选：写下你哪里不确定，例如“我把 x=3 加到后面了”。"
        auto-height
      />
      <button class="analyze-button" :loading="loading" @tap="analyzePhoto">调用 AI 分析</button>
    </view>

    <view v-if="analysis" class="result-panel">
      <view class="result-block">
        <text class="block-title">识别出的题目</text>
        <text class="block-text">{{ analysis.questionText || '未识别到题目，请重新拍照。' }}</text>
      </view>
      <view class="result-block">
        <text class="block-title">学生解题痕迹</text>
        <text class="block-text">{{ analysis.studentWorkText || '暂时没看到清楚的解题过程，你可以直接在下方补充。' }}</text>
      </view>
      <view class="tag-row">
        <view class="tag">
          <text class="tag-label">知识点</text>
          <text class="tag-value">{{ analysis.knowledgePoint }}</text>
        </view>
        <view class="tag">
          <text class="tag-label">错因</text>
          <text class="tag-value">{{ analysis.errorTag }}</text>
        </view>
      </view>
    </view>

    <view v-if="analysis" class="dialogue-panel">
      <view class="dialogue-head">
        <text class="dialogue-title">追问订正</text>
        <text class="dialogue-stage">{{ stageText }} · L{{ hintLevel }}</text>
      </view>

      <scroll-view class="chat" scroll-y :scroll-into-view="lastMessageId">
        <view
          v-for="(message, index) in tutorMessages"
          :id="`msg-${index}`"
          :key="index"
          :class="['bubble', message.role === 'student' ? 'student' : 'assistant']"
        >
          <text>{{ message.content }}</text>
        </view>
      </scroll-view>

      <view class="reply-box">
        <textarea
          class="reply-input"
          v-model="studentReply"
          placeholder="把你的想法写在这里，AI 会继续追问。"
          auto-height
        />
        <view class="reply-actions">
          <button class="help-button" :disabled="followLoading" @tap="askForHint">我不会</button>
          <button class="send-button" :loading="followLoading" @tap="sendStudentReply">发送回答</button>
        </view>
      </view>

      <view v-if="canFinish" class="finish-panel">
        <text class="finish-title">可以生成订正卡了</text>
        <text class="finish-text">订正卡会记录题目、错因、追问过程和你的最终总结。</text>
        <button class="secondary-button full" @tap="saveAndOpenCard">生成订正卡</button>
      </view>
      <view v-else class="pending-panel">
        <text>先完成 AI 的追问和自己的错因总结，再生成订正卡。</text>
      </view>
    </view>
  </view>
</template>

<script setup>
import { computed, ref } from 'vue'
import { onShow } from '@dcloudio/uni-app'

import { followUpTutor, generateCorrectionCard, generateDiagnosis, solvePhoto } from '../../utils/api'
import { requireLogin } from '../../utils/auth'
import { saveCard, setCurrentCard } from '../../utils/storage'

const imagePath = ref('')
const imageName = ref('question.jpg')
const imageMimeType = ref('image/jpeg')
const studentNote = ref('')
const analysis = ref(null)
const draftCard = ref(null)
const loading = ref(false)
const followLoading = ref(false)
const tutorMessages = ref([])
const studentReply = ref('')
const followUpStage = ref('')
const canFinish = ref(false)
const finalSummary = ref('')
const hintLevel = ref(1)

const lastMessageId = computed(() => `msg-${Math.max(tutorMessages.value.length - 1, 0)}`)

const stageText = computed(() => {
  if (canFinish.value) return '已完成'
  if (followUpStage.value === 'summary') return '总结错因'
  if (followUpStage.value === 'guide') return '继续引导'
  return '第一追问'
})

function guessMimeType(path = '') {
  const lowerPath = path.toLowerCase()
  if (lowerPath.endsWith('.png')) return 'image/png'
  if (lowerPath.endsWith('.webp')) return 'image/webp'
  return 'image/jpeg'
}

function resetConversation() {
  analysis.value = null
  draftCard.value = null
  tutorMessages.value = []
  studentReply.value = ''
  followUpStage.value = ''
  canFinish.value = false
  finalSummary.value = ''
  hintLevel.value = 1
}

function chooseImage(source) {
  uni.chooseImage({
    count: 1,
    sizeType: ['compressed'],
    sourceType: [source],
    success(result) {
      const filePath = result.tempFilePaths?.[0]
      if (!filePath) return

      imagePath.value = filePath
      imageMimeType.value = guessMimeType(filePath)
      imageName.value = filePath.split('/').pop() || 'question.jpg'
      resetConversation()
    },
    fail() {
      uni.showToast({
        title: '没有选择图片',
        icon: 'none'
      })
    }
  })
}

function clearImage() {
  imagePath.value = ''
  resetConversation()
}

async function analyzePhoto() {
  if (!imagePath.value) {
    uni.showToast({
      title: '请先拍照或选图',
      icon: 'none'
    })
    return
  }

  loading.value = true
  try {
    const result = await solvePhoto({
      filePath: imagePath.value,
      fileName: imageName.value,
      mimeType: imageMimeType.value,
      studentNote: studentNote.value,
      unit: '一次函数'
    })

    analysis.value = result.result
    draftCard.value = result.card
    followUpStage.value = 'question'
    canFinish.value = false
    finalSummary.value = ''
    hintLevel.value = 1
    tutorMessages.value = [
      {
        role: 'assistant',
        content: result.result?.firstQuestion || result.card?.guidingQuestion || '你先说说自己是从哪一步开始不确定的？'
      }
    ]
  } catch (error) {
    uni.showModal({
      title: '图片分析失败',
      content: error.message || '请检查本地后端和 Coze 配置。',
      showCancel: false
    })
  } finally {
    loading.value = false
  }
}

async function sendStudentReply() {
  const content = studentReply.value.trim()
  if (!content || followLoading.value) return

  await submitReply(content)
}

async function askForHint() {
  if (followLoading.value) return

  hintLevel.value = Math.min(hintLevel.value + 1, 4)
  await submitReply('我还不会，请给我更具体一点的提示。')
}

async function submitReply(content) {
  tutorMessages.value.push({
    role: 'student',
    content
  })
  studentReply.value = ''
  followLoading.value = true

  try {
    const result = await followUpTutor({
      analysis: analysis.value,
      card: draftCard.value,
      messages: tutorMessages.value,
      hintLevel: hintLevel.value
    })

    tutorMessages.value.push({
      role: 'assistant',
      content: result.reply
    })
    followUpStage.value = result.stage
    canFinish.value = Boolean(result.canFinish)
    hintLevel.value = result.hintLevel || hintLevel.value
    if (result.summary) finalSummary.value = result.summary
  } catch (error) {
    uni.showModal({
      title: '追问失败',
      content: error.message || '请稍后再试。',
      showCancel: false
    })
  } finally {
    followLoading.value = false
  }
}

async function saveAndOpenCard() {
  if (!draftCard.value) return

  if (!canFinish.value) {
    uni.showToast({
      title: '请先完成追问总结',
      icon: 'none'
    })
    return
  }

  try {
    const diagnosisResult = await generateDiagnosis({
      analysis: analysis.value,
      card: draftCard.value,
      messages: tutorMessages.value,
      hintLevel: hintLevel.value
    })
    const cardResult = await generateCorrectionCard({
      analysis: analysis.value,
      card: draftCard.value,
      diagnosis: diagnosisResult.diagnosis || diagnosisResult,
      messages: tutorMessages.value,
      studentSummary: finalSummary.value
    })
    const saved = saveCard({
      ...draftCard.value,
      ...(cardResult.card || cardResult),
      imagePath: imagePath.value,
      analysis: analysis.value,
      diagnosis: diagnosisResult.diagnosis || diagnosisResult,
      messages: tutorMessages.value,
      studentSummary: finalSummary.value,
      hintLevel: hintLevel.value
    })
    setCurrentCard(saved)
    uni.navigateTo({ url: '/pages/card/card' })
  } catch (error) {
    uni.showModal({
      title: '订正卡生成失败',
      content: error.message || '请稍后再试。',
      showCancel: false
    })
  }
}

onShow(() => {
  requireLogin()
})
</script>

<style>
.page {
  min-height: 100vh;
  padding: 30rpx;
  background: #f5f1e8;
  color: #17211a;
  box-sizing: border-box;
}

.header {
  padding: 28rpx 0 18rpx;
}

.title {
  display: block;
  font-size: 44rpx;
  font-weight: 700;
}

.subtitle {
  display: block;
  margin-top: 10rpx;
  color: #66705f;
  font-size: 26rpx;
  line-height: 1.5;
}

.capture-panel,
.note-panel,
.result-panel,
.dialogue-panel {
  margin-top: 24rpx;
  padding: 26rpx;
  border: 2rpx solid #17211a;
  border-radius: 8rpx;
  background: #fffaf0;
}

.preview-wrap {
  position: relative;
  height: 420rpx;
  border: 2rpx solid #17211a;
  border-radius: 8rpx;
  overflow: hidden;
  background: #efe6d4;
}

.preview-image {
  width: 100%;
  height: 100%;
}

.mini-button {
  position: absolute;
  right: 18rpx;
  top: 18rpx;
  height: 60rpx;
  padding: 0 24rpx;
  border: 2rpx solid #17211a;
  color: #17211a;
  background: #f2cf5b;
  font-size: 25rpx;
}

.camera-placeholder {
  display: flex;
  min-height: 360rpx;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border: 2rpx dashed #8b846f;
  border-radius: 8rpx;
  background: #f7edd8;
  text-align: center;
}

.camera-icon {
  position: relative;
  width: 124rpx;
  height: 88rpx;
  border: 5rpx solid #17211a;
  border-radius: 12rpx;
  background: #2f7d63;
}

.camera-icon::before {
  content: '';
  position: absolute;
  left: 24rpx;
  top: -24rpx;
  width: 44rpx;
  height: 22rpx;
  border: 5rpx solid #17211a;
  border-bottom: 0;
  border-radius: 10rpx 10rpx 0 0;
  background: #f2cf5b;
}

.lens {
  position: absolute;
  left: 38rpx;
  top: 20rpx;
  width: 42rpx;
  height: 42rpx;
  border: 5rpx solid #17211a;
  border-radius: 50%;
  background: #fffaf0;
}

.placeholder-title {
  display: block;
  margin-top: 28rpx;
  font-size: 32rpx;
  font-weight: 700;
}

.placeholder-text {
  display: block;
  max-width: 500rpx;
  margin-top: 12rpx;
  color: #66705f;
  font-size: 26rpx;
  line-height: 1.5;
}

.capture-actions {
  display: flex;
  gap: 18rpx;
  margin-top: 24rpx;
}

button {
  margin: 0;
  border-radius: 8rpx;
}

button::after {
  border: 0;
}

.primary-button,
.secondary-button,
.analyze-button,
.send-button,
.help-button {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 84rpx;
  border: 2rpx solid #17211a;
  font-size: 29rpx;
}

.primary-button {
  flex: 1;
  color: #fffaf0;
  background: #1f6b55;
}

.secondary-button {
  flex: 1;
  color: #17211a;
  background: #f2cf5b;
}

.secondary-button.full {
  width: 100%;
  margin-top: 24rpx;
}

.label {
  display: block;
  margin-bottom: 12rpx;
  font-size: 27rpx;
  font-weight: 700;
}

.textarea,
.reply-input {
  width: 100%;
  min-height: 118rpx;
  padding: 22rpx;
  border: 2rpx solid #d5c8ad;
  border-radius: 6rpx;
  background: #fffdf7;
  color: #17211a;
  font-size: 28rpx;
  line-height: 1.55;
  box-sizing: border-box;
}

.analyze-button {
  width: 100%;
  margin-top: 22rpx;
  color: #fffaf0;
  background: #c84d2f;
}

.result-block {
  padding: 22rpx 0;
  border-bottom: 2rpx solid #e1d6bf;
}

.block-title {
  display: block;
  color: #66705f;
  font-size: 25rpx;
}

.block-text {
  display: block;
  margin-top: 10rpx;
  font-size: 28rpx;
  line-height: 1.6;
}

.tag-row {
  display: flex;
  gap: 18rpx;
  margin-top: 22rpx;
}

.tag {
  flex: 1;
  padding: 22rpx;
  border: 2rpx solid #17211a;
  border-radius: 8rpx;
  background: #f7edd8;
}

.tag-label,
.tag-value {
  display: block;
}

.tag-label {
  color: #66705f;
  font-size: 23rpx;
}

.tag-value {
  margin-top: 8rpx;
  font-size: 28rpx;
  font-weight: 700;
}

.dialogue-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20rpx;
}

.dialogue-title {
  font-size: 34rpx;
  font-weight: 700;
}

.dialogue-stage {
  padding: 8rpx 16rpx;
  border: 2rpx solid #17211a;
  border-radius: 6rpx;
  background: #dce9dc;
  font-size: 23rpx;
}

.chat {
  max-height: 560rpx;
  padding: 4rpx 0;
}

.bubble {
  max-width: 86%;
  margin: 16rpx 0;
  padding: 22rpx;
  border: 2rpx solid #17211a;
  border-radius: 8rpx;
  font-size: 28rpx;
  line-height: 1.55;
}

.assistant {
  background: #dce9dc;
}

.student {
  margin-left: auto;
  background: #f7edd8;
}

.reply-box {
  margin-top: 20rpx;
}

.reply-actions {
  display: flex;
  gap: 16rpx;
  margin-top: 16rpx;
}

.help-button {
  width: 190rpx;
  color: #17211a;
  background: #f2cf5b;
}

.send-button {
  flex: 1;
  color: #fffaf0;
  background: #1f6b55;
}

.finish-panel,
.pending-panel {
  margin-top: 22rpx;
  padding: 22rpx;
  border: 2rpx solid #17211a;
  border-radius: 8rpx;
  background: #f7edd8;
}

.finish-title {
  display: block;
  font-size: 30rpx;
  font-weight: 700;
}

.finish-text,
.pending-panel {
  color: #5d6559;
  font-size: 25rpx;
  line-height: 1.5;
}
</style>

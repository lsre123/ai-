<template>
  <view class="page">
    <view v-if="card" class="sheet">
      <text class="title">{{ card.title || '错题订正卡' }}</text>
      <view class="row">
        <text class="label">知识点</text>
        <text class="value">{{ card.knowledgePoint }}</text>
      </view>
      <view class="row">
        <text class="label">错因类型</text>
        <text class="value">{{ card.errorTag }}</text>
      </view>
      <view v-if="card.breakpoint" class="row">
        <text class="label">思维断点</text>
        <text class="value">{{ card.breakpoint }}</text>
      </view>
      <view class="block">
        <text class="block-title">题目</text>
        <text class="block-text">{{ card.question }}</text>
      </view>
      <view class="block">
        <text class="block-title">我的原思路</text>
        <text class="block-text">{{ card.originalThinking }}</text>
      </view>
      <view class="block">
        <text class="block-title">错因说明</text>
        <text class="block-text">{{ card.errorReason }}</text>
      </view>
      <view v-if="card.messages && card.messages.length" class="block">
        <text class="block-title">追问过程</text>
        <view
          v-for="(message, index) in card.messages"
          :key="index"
          :class="['dialogue-line', message.role === 'student' ? 'student' : 'assistant']"
        >
          <text class="speaker">{{ message.role === 'student' ? '我' : 'AI' }}</text>
          <text class="dialogue-text">{{ message.content }}</text>
        </view>
      </view>
      <view v-if="card.studentSummary" class="block">
        <text class="block-title">我的总结</text>
        <text class="block-text">{{ card.studentSummary }}</text>
      </view>
      <view class="block">
        <text class="block-title">订正提醒</text>
        <text class="block-text">{{ card.correctionTip }}</text>
      </view>
      <view v-if="card.correctThinking" class="block">
        <text class="block-title">正确思路</text>
        <text class="block-text">{{ card.correctThinking }}</text>
      </view>
      <view class="block">
        <text class="block-title">同类练习</text>
        <text class="block-text">{{ card.variantQuestion || card.nextPractice }}</text>
      </view>
      <view v-if="card.nextReviewAt" class="block">
        <text class="block-title">下次复习</text>
        <text class="block-text">{{ card.nextReviewAt }}</text>
      </view>
      <view class="block">
        <text class="block-title">反思句</text>
        <text class="block-text">{{ card.reflectionPrompt }}</text>
      </view>
    </view>

    <view v-else class="empty">
      <text>暂无订正卡，请先完成一次错题对话。</text>
    </view>
  </view>
</template>

<script setup>
import { ref } from 'vue'
import { onShow } from '@dcloudio/uni-app'

import { requireLogin } from '../../utils/auth'
import { getCurrentCard } from '../../utils/storage'

const card = ref(null)

onShow(() => {
  if (!requireLogin()) return

  card.value = getCurrentCard()
})
</script>

<style>
.page {
  min-height: 100vh;
  padding: 30rpx;
  background: #f5f1e8;
  color: #17211a;
  box-sizing: border-box;
}

.sheet,
.empty {
  padding: 30rpx;
  border: 2rpx solid #17211a;
  border-radius: 8rpx;
  background: #fffaf0;
}

.sheet {
  box-shadow: 8rpx 8rpx 0 #17211a;
}

.title {
  display: block;
  margin-bottom: 26rpx;
  font-size: 42rpx;
  font-weight: 700;
}

.row {
  display: flex;
  justify-content: space-between;
  gap: 20rpx;
  padding: 18rpx 0;
  border-top: 2rpx solid #e1d6bf;
}

.label {
  color: #66705f;
  font-size: 26rpx;
}

.value {
  font-size: 27rpx;
  font-weight: 700;
}

.block {
  padding: 22rpx 0;
  border-top: 2rpx solid #e1d6bf;
}

.block-title {
  display: block;
  color: #66705f;
  font-size: 25rpx;
}

.block-text {
  display: block;
  margin-top: 10rpx;
  font-size: 28rpx;
  line-height: 1.6;
}

.dialogue-line {
  margin-top: 14rpx;
  padding: 18rpx;
  border: 2rpx solid #17211a;
  border-radius: 8rpx;
}

.dialogue-line.assistant {
  background: #dce9dc;
}

.dialogue-line.student {
  background: #f7edd8;
}

.speaker {
  display: block;
  color: #66705f;
  font-size: 23rpx;
  font-weight: 700;
}

.dialogue-text {
  display: block;
  margin-top: 6rpx;
  font-size: 27rpx;
  line-height: 1.55;
}

.empty {
  color: #66705f;
  font-size: 28rpx;
  line-height: 1.6;
}
</style>

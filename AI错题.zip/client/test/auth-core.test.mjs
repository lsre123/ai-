import test from 'node:test'
import assert from 'node:assert/strict'

import { createLocalAuthUser } from '../src/utils/auth-core.mjs'

test('creates a local auth user from WeChat profile and login code', () => {
  const user = createLocalAuthUser({
    userInfo: {
      nickName: '小林',
      avatarUrl: 'https://example.com/avatar.png'
    },
    loginResult: {
      code: 'wx-login-code'
    },
    now: () => new Date('2026-05-12T08:00:00.000Z'),
    random: () => 0.123456
  })

  assert.equal(user.id, 'local-weixin-4fzyo8')
  assert.equal(user.nickName, '小林')
  assert.equal(user.avatarUrl, 'https://example.com/avatar.png')
  assert.equal(user.loginCode, 'wx-login-code')
  assert.equal(user.provider, 'weixin')
  assert.equal(user.loginAt, '2026-05-12T08:00:00.000Z')
})

test('falls back to a demo nickname when profile fields are missing', () => {
  const user = createLocalAuthUser({
    userInfo: {},
    loginResult: {},
    now: () => new Date('2026-05-12T08:00:00.000Z'),
    random: () => 0.5
  })

  assert.equal(user.nickName, '本地演示用户')
  assert.equal(user.avatarUrl, '')
  assert.equal(user.loginCode, '')
})

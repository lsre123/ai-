import assert from 'node:assert/strict'
import test from 'node:test'

import { createApp } from '../src/app.js'
import { normalizePhotoWorkflowResult } from '../src/cozeClient.js'

test('health endpoint reports mock mode without Coze credentials', async () => {
  const app = createApp({
    env: {},
    fetchImpl: async () => {
      throw new Error('Coze should not be called in mock mode')
    }
  })

  const response = await app.inject({
    method: 'GET',
    url: '/api/health'
  })

  assert.equal(response.statusCode, 200)
  assert.deepEqual(JSON.parse(response.body), {
    ok: true,
    aiMode: 'mock',
    service: 'ai-math-tutor'
  })
})

test('chat endpoint returns a guided reply and card draft in mock mode', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/chat',
    body: {
      question: '已知一次函数 y=2x+1，求 x=3 时 y 的值',
      studentAnswer: '我觉得 y=2x+3',
      messages: []
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.mode, 'mock')
  assert.match(payload.reply, /先|想一想|代入/)
  assert.equal(payload.card.knowledgePoint, '一次函数')
  assert.ok(payload.card.nextPractice.includes('一次函数'))
})

test('photo endpoint returns recognized text and a correction card in mock mode', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/photo-solve',
    body: {
      imageBase64: 'ZmFrZS1pbWFnZQ==',
      fileName: 'question.jpg',
      mimeType: 'image/jpeg',
      studentNote: '我把 x=3 直接加到后面了'
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.mode, 'mock')
  assert.match(payload.result.questionText, /一次函数/)
  assert.match(payload.result.firstQuestion, /代入|位置|哪里/)
  assert.equal(payload.card.knowledgePoint, '一次函数')
  assert.equal(payload.card.errorTag, '计算错误')
})

test('photo upload endpoint accepts an image buffer in mock mode', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/photo-solve-upload',
    body: {
      imageBuffer: Buffer.from('fake-image'),
      fileName: 'question.jpg',
      mimeType: 'image/jpeg',
      studentNote: '我把 x=3 直接加到后面了'
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.mode, 'mock')
  assert.match(payload.result.firstQuestion, /代入|位置|哪里/)
})

test('diagnosis endpoint returns a structured thinking breakpoint', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/diagnosis',
    body: {
      analysis: {
        questionText: '已知一次函数 y=2x+1，求 x=3 时 y 的值。',
        errorTag: '建模错误'
      },
      messages: [
        { role: 'student', content: '我不知道 x 应该放在哪里。' }
      ],
      hintLevel: 2
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.mode, 'mock')
  assert.ok(payload.mainBreakpoint)
  assert.equal(payload.hintLevel, 2)
  assert.ok(Array.isArray(payload.processMap))
})

test('correction card endpoint includes review and variant practice fields', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/correction-card',
    body: {
      analysis: {
        questionText: '已知一次函数 y=2x+1，求 x=3 时 y 的值。',
        knowledgePoint: '一次函数',
        studentWorkText: '我把 3 加到常数项后面。',
        errorTag: '计算错误'
      },
      messages: [
        { role: 'student', content: '我下次要先确认代入位置。' }
      ]
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.mode, 'mock')
  assert.equal(payload.card.knowledgePoint, '一次函数')
  assert.ok(payload.card.nextReviewAt)
  assert.ok(payload.card.variantQuestion)
})

test('correction card endpoint aligns fallback fields with a CAD question', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/correction-card',
    body: {
      analysis: {
        questionText: '英文缩写 CAD 的中文意思是？A）计算机辅助设计 B）计算机辅助制造 C）计算机辅助教学 D）计算机辅助管理',
        knowledgePoint: '计算机应用',
        studentWorkText: '',
        errorTag: '概念混淆'
      },
      card: {
        originalThinking: '学生可能把 x 的值直接加到常数项后面。',
        correctionTip: '把已知条件、所求问题和关键步骤分开写，先说明依据，再进行计算。',
        nextPractice: '同类练习：已知一次函数 y = 3x - 2，求 x = 4 时 y 的值。',
        correctThinking: '先确认函数表达式，再把 x = 3 代入。'
      },
      messages: [
        { role: 'student', content: 'Design 是设计的意思' }
      ]
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.card.knowledgePoint, '计算机应用')
  assert.match(payload.card.originalThinking, /暂未留下完整原思路|追问过程/)
  assert.match(payload.card.correctionTip, /CAD|Design|缩写/)
  assert.match(payload.card.correctThinking, /CAD|Design|设计/)
  assert.match(payload.card.variantQuestion, /CAI|CAM|计算机辅助/)
  assert.doesNotMatch(payload.card.originalThinking, /x|常数项|一次函数/)
  assert.doesNotMatch(payload.card.variantQuestion, /一次函数|x = 4/)
})

test('profile endpoint returns personal aggregates', async () => {
  const app = createApp({ env: {} })

  const profileResponse = await app.inject({
    method: 'GET',
    url: '/api/profile?userId=demo_user'
  })
  const profile = JSON.parse(profileResponse.body)

  assert.equal(profileResponse.statusCode, 200)
  assert.ok(Array.isArray(profile.topBreakpoints))
  assert.ok(Array.isArray(profile.topKnowledgePoints))
  assert.ok(Array.isArray(profile.topErrors))
})

test('normalizes Coze workflow result when result is an escaped JSON string', () => {
  const payload = {
    data: {
      result: JSON.stringify({
        analysis: '学生把 x 的值代入位置弄错了。',
        errorTag: '计算错误',
        firstQuestion: '你能先说说 x=3 应该代入哪里吗？',
        knowledgePoint: '一次函数',
        questionText: '已知 y=2x+1，求 x=3 时 y 的值。',
        studentWorkText: '把 3 加到常数项后面。'
      })
    }
  }

  const result = normalizePhotoWorkflowResult(payload)

  assert.equal(result.questionText, '已知 y=2x+1，求 x=3 时 y 的值。')
  assert.equal(result.errorTag, '计算错误')
  assert.match(result.firstQuestion, /x=3/)
})

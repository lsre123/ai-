import assert from 'node:assert/strict'
import test from 'node:test'

import { createApp } from '../src/app.js'

test('follow-up endpoint keeps guiding until student gives conclusion and reflection', async () => {
  const app = createApp({ env: {} })

  const firstResponse = await app.inject({
    method: 'POST',
    url: '/api/follow-up',
    body: {
      analysis: {
        questionText: 'Simplify (-2a^2)^3',
        studentWorkText: '(-2a^2)^3 = -2a^6',
        knowledgePoint: 'power of a product',
        errorTag: 'rule misuse',
        firstQuestion: 'Which factors need to be raised to the third power?'
      },
      messages: [
        { role: 'assistant', content: 'Which factors need to be raised to the third power?' },
        { role: 'student', content: 'Both -2 and a^2 need the power.' }
      ]
    }
  })

  const firstPayload = JSON.parse(firstResponse.body)

  assert.equal(firstResponse.statusCode, 200)
  assert.equal(firstPayload.canFinish, false)
  assert.equal(firstPayload.stage, 'guide')
  assert.ok(firstPayload.reply.length > 10)

  const summaryResponse = await app.inject({
    method: 'POST',
    url: '/api/follow-up',
    body: {
      analysis: {
        questionText: 'Simplify (-2a^2)^3',
        studentWorkText: '(-2a^2)^3 = -2a^6',
        knowledgePoint: 'power of a product',
        errorTag: 'rule misuse',
        firstQuestion: 'Which factors need to be raised to the third power?'
      },
      messages: [
        { role: 'assistant', content: 'Which factors need to be raised to the third power?' },
        { role: 'student', content: 'Both -2 and a^2 need the power.' },
        { role: 'assistant', content: 'Now compute each part.' },
        { role: 'student', content: 'So the answer should be -8a^6.' }
      ]
    }
  })

  const summaryPayload = JSON.parse(summaryResponse.body)

  assert.equal(summaryPayload.canFinish, false)
  assert.equal(summaryPayload.stage, 'summary')
  assert.match(summaryPayload.reply, /错因|错在|下次/)

  const finalResponse = await app.inject({
    method: 'POST',
    url: '/api/follow-up',
    body: {
      analysis: {
        questionText: 'Simplify (-2a^2)^3',
        studentWorkText: '(-2a^2)^3 = -2a^6',
        knowledgePoint: 'power of a product',
        errorTag: 'rule misuse',
        firstQuestion: 'Which factors need to be raised to the third power?'
      },
      messages: [
        { role: 'assistant', content: 'Which factors need to be raised to the third power?' },
        { role: 'student', content: 'Both -2 and a^2 need the power.' },
        { role: 'assistant', content: 'Now compute each part.' },
        { role: 'student', content: '(-2)^3 is -8 and (a^2)^3 is a^6.' },
        { role: 'assistant', content: 'Please summarize the mistake.' },
        { role: 'student', content: 'The answer should be -8a^6 because the exponent applies to every factor. I was wrong because I only powered a^2, so next time I need to check every factor.' }
      ]
    }
  })

  const finalPayload = JSON.parse(finalResponse.body)

  assert.equal(finalResponse.statusCode, 200)
  assert.equal(finalPayload.canFinish, true)
  assert.equal(finalPayload.stage, 'finish')
})

test('follow-up does not finish when student asks for direct answer', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/follow-up',
    body: {
      analysis: {
        questionText: '计算机最早的应用领域是？A）辅助工程 B）过程控制 C）数据处理 D）数值计算',
        studentWorkText: '学生选择了 A',
        knowledgePoint: '计算机应用领域',
        errorTag: '概念混淆',
        firstQuestion: '题干里的关键词是什么？'
      },
      messages: [
        { role: 'assistant', content: '题干里的关键词是什么？' },
        { role: 'student', content: '最早' },
        { role: 'assistant', content: '现在可以把“未明确作答选项，暂无法判断具体错因”写进订正卡，并补上一句自己的提醒。' },
        { role: 'student', content: '所以这题选什么' }
      ]
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.canFinish, false)
  assert.equal(payload.stage, 'guide')
  assert.match(payload.reply, /最早|数值计算|选哪项/)
})

test('follow-up does not finish just because there are many unclear replies', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/follow-up',
    body: {
      analysis: {
        questionText: '计算机最早的应用领域是？A）辅助工程 B）过程控制 C）数据处理 D）数值计算',
        studentWorkText: '学生选择了 A',
        knowledgePoint: '计算机应用领域',
        errorTag: '概念混淆',
        firstQuestion: '题干里的关键词是什么？'
      },
      messages: [
        { role: 'assistant', content: '题干里的关键词是什么？' },
        { role: 'student', content: '不知道' },
        { role: 'assistant', content: '先找关键词。' },
        { role: 'student', content: '不会' },
        { role: 'assistant', content: '再看选项。' },
        { role: 'student', content: '不确定' },
        { role: 'assistant', content: '试着排除。' },
        { role: 'student', content: '没有' }
      ]
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.canFinish, false)
  assert.equal(payload.stage, 'guide')
  assert.match(payload.reply, /最早|数值计算|答案是/)
})

test('follow-up gives short direct nudge after student names the mistake but not the answer', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/follow-up',
    body: {
      analysis: {
        questionText: '计算机最早的应用领域是？A）辅助工程 B）过程控制 C）数据处理 D）数值计算',
        studentWorkText: '学生选择了 A',
        knowledgePoint: '计算机应用领域',
        errorTag: '概念混淆'
      },
      messages: [
        { role: 'assistant', content: '要害：题目问“最早”。最早的应用是数值计算。请你只回答两点：选哪项？你刚才为什么会选错？' },
        { role: 'student', content: '没有记牢，英文缩略词' }
      ]
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.canFinish, false)
  assert.equal(payload.stage, 'guide')
  assert.match(payload.reply, /数值计算|选哪项/)
})

test('follow-up finishes when earliest-use answer has a natural mistake summary', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/follow-up',
    body: {
      analysis: {
        questionText: '计算机最早的应用领域是？A）辅助工程 B）过程控制 C）数据处理 D）数值计算',
        studentWorkText: '学生选择了 A',
        knowledgePoint: '计算机应用领域',
        errorTag: '概念混淆'
      },
      messages: [
        { role: 'assistant', content: '先看关键词“最早”。早期计算机最先解决的是大量计算问题。四个选项里，哪个写的是“数值计算”？你先说选项。' },
        { role: 'student', content: 'D' },
        { role: 'assistant', content: '选D对了。关键是“最早”：早期计算机主要用来做大量计算。现在请你用自己的话说一句理由。' },
        { role: 'student', content: '最早用途' },
        { role: 'assistant', content: '这句理由可以。最后补错因：你刚才是不是把“辅助教学/辅助工程”和“最早用途”混在一起了？用自己的话说一遍。' },
        { role: 'student', content: '记错，先看最早' }
      ]
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.canFinish, true)
  assert.equal(payload.stage, 'finish')
  assert.match(payload.reply, /可以了|生成订正卡/)
})

test('follow-up mistake prompt uses current earliest-use option text', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/follow-up',
    body: {
      analysis: {
        questionText: '计算机最早的应用领域是？A）辅助工程 B）过程控制 C）数据处理 D）数值计算',
        studentWorkText: '学生选择了 A',
        knowledgePoint: '计算机应用领域',
        errorTag: '概念混淆'
      },
      messages: [
        { role: 'assistant', content: '选D对了。关键是“最早”：早期计算机主要用来做大量计算。现在请你用自己的话说一句理由。' },
        { role: 'student', content: '最早用途' }
      ]
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.canFinish, false)
  assert.equal(payload.stage, 'summary')
  assert.match(payload.reply, /辅助工程|最早用途/)
  assert.doesNotMatch(payload.reply, /辅助教学/)
})

test('follow-up recognizes a standalone choice as an answer', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/follow-up',
    body: {
      analysis: {
        questionText: 'CAI 指的是？A）计算机辅助教学 B）过程控制 C）数据处理 D）数值计算',
        studentWorkText: '学生选择不确定',
        knowledgePoint: '计算机应用',
        errorTag: '概念混淆'
      },
      messages: [
        { role: 'assistant', content: '先看题干关键词，再看选项。' },
        { role: 'student', content: 'A' }
      ]
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.canFinish, false)
  assert.equal(payload.stage, 'guide')
  assert.match(payload.reply, /选了A|选的是A|理由/)
})

test('follow-up asks for reason after standalone correct choice', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/follow-up',
    body: {
      analysis: {
        questionText: '计算机最早的应用领域是？A）辅助工程 B）过程控制 C）数据处理 D）数值计算',
        studentWorkText: '学生选择A',
        knowledgePoint: '计算机应用领域',
        errorTag: '概念混淆'
      },
      messages: [
        { role: 'assistant', content: '先看关键词“最早”。' },
        { role: 'student', content: 'D' }
      ]
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.canFinish, false)
  assert.equal(payload.stage, 'guide')
  assert.match(payload.reply, /方向对了|为什么是D|理由/)
})

test('follow-up does not leak OCR placeholder into choice text', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/follow-up',
    body: {
      analysis: {
        questionText: '计算机最早的应用领域是？A）辅助工程 B）过程控制 C）数据处理 D）数值计算',
        studentWorkText: '未识别到明显作答',
        knowledgePoint: '计算机应用领域',
        errorTag: '概念混淆'
      },
      messages: [
        { role: 'assistant', content: '选D对了。再说清理由。' },
        { role: 'student', content: '因为早期计算机最先解决的是大量计算问题' }
      ]
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.canFinish, false)
  assert.equal(payload.stage, 'summary')
  assert.doesNotMatch(payload.reply, /未识别|明显作答/)
  assert.match(payload.reply, /错因|混在一起|自己的话/)
})

test('follow-up remembers previous correct choice when student only gives reason', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/follow-up',
    body: {
      analysis: {
        questionText: '计算机最早的应用领域是？A）辅助工程 B）过程控制 C）数据处理 D）数值计算',
        studentWorkText: '未识别到明显作答',
        knowledgePoint: '计算机应用领域',
        errorTag: '概念混淆'
      },
      messages: [
        { role: 'assistant', content: '你先说选项。' },
        { role: 'student', content: 'D' },
        { role: 'assistant', content: '选D对了。再说清理由。' },
        { role: 'student', content: '因为早期计算机最先解决的是大量计算问题' }
      ]
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.canFinish, false)
  assert.equal(payload.stage, 'summary')
  assert.match(payload.reply, /理由可以|最后补错因|混在一起/)
})

test('follow-up recognizes option text answer like 辅助设计', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/follow-up',
    body: {
      analysis: {
        questionText: 'CAD 是指什么？A）辅助教学 B）辅助设计 C）过程控制 D）数据处理',
        studentWorkText: '',
        knowledgePoint: '计算机应用',
        errorTag: '概念混淆'
      },
      messages: [
        { role: 'assistant', content: '先看题干关键词，再看选项。' },
        { role: 'student', content: '辅助设计' }
      ]
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.canFinish, false)
  assert.equal(payload.stage, 'guide')
  assert.match(payload.reply, /答案对|关键点|CAD|Design|为什么是辅助设计/)
  assert.doesNotMatch(payload.reply, /先看题干关键词|你先说选项/)
})

test('follow-up does not turn a correct text answer into a wrong answer', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/follow-up',
    body: {
      analysis: {
        questionText: 'CAD 是指什么？A）辅助教学 B）辅助设计 C）过程控制 D）数据处理',
        studentWorkText: '',
        knowledgePoint: '计算机应用',
        errorTag: '概念混淆'
      },
      messages: [
        { role: 'assistant', content: '先看题干关键词，再看选项。' },
        { role: 'student', content: '辅助设计' },
        { role: 'assistant', content: '这个答案对。关键点是 CAD 里的 D 表示 Design，也就是“设计”。' },
        { role: 'student', content: '因为 CAD 是计算机辅助设计' }
      ]
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.canFinish, true)
  assert.equal(payload.stage, 'finish')
  assert.match(payload.reply, /可以了|生成订正卡/)
  assert.doesNotMatch(payload.reply, /不稳|重新判断|错误答案/)
})

test('follow-up finishes after Design explanation for CAD answer', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/follow-up',
    body: {
      analysis: {
        questionText: 'CAD 是指什么？A）辅助教学 B）辅助设计 C）过程控制 D）数据处理',
        studentWorkText: '',
        knowledgePoint: '计算机应用',
        errorTag: '概念混淆'
      },
      messages: [
        { role: 'assistant', content: '这个答案对。关键点是 CAD 里的 D 表示 Design，也就是“设计”。现在请你用自己的话说一句：为什么是计算机辅助设计？' },
        { role: 'student', content: 'Design是设计的意思' }
      ]
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.canFinish, true)
  assert.equal(payload.stage, 'finish')
  assert.match(payload.reply, /可以了|生成订正卡/)
  assert.doesNotMatch(payload.reply, /先看题干关键词|你先说选项/)
})

test('follow-up trusts previous assistant confirmation for CAD answer', async () => {
  const app = createApp({ env: {} })

  const response = await app.inject({
    method: 'POST',
    url: '/api/follow-up',
    body: {
      analysis: {
        questionText: 'CAD 是指什么？A）辅助教学 B）辅助设计 C）过程控制 D）数据处理',
        studentWorkText: '',
        knowledgePoint: '计算机应用',
        errorTag: '概念混淆'
      },
      messages: [
        { role: 'assistant', content: '这个答案对。关键点是 CAD 里的 D 表示 Design，也就是“设计”。现在请你用自己的话说一句：为什么是计算机辅助设计？' },
        { role: 'student', content: 'Design是设计的意思' }
      ]
    }
  })

  const payload = JSON.parse(response.body)

  assert.equal(response.statusCode, 200)
  assert.equal(payload.canFinish, true)
  assert.equal(payload.stage, 'finish')
  assert.match(payload.reply, /生成订正卡/)
})

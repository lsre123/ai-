import assert from 'node:assert/strict'
import test from 'node:test'

import { buildTutorSystemPrompt, classifyLocalError } from '../src/prompt.js'

test('tutor prompt enforces guided questioning instead of direct answers', () => {
  const prompt = buildTutorSystemPrompt({ unitName: '一次函数' })

  assert.match(prompt, /初中生/)
  assert.match(prompt, /一次函数/)
  assert.match(prompt, /不得直接给出最终答案/)
  assert.match(prompt, /每次只提出一个/)
})

test('local classifier recognizes graph-reading mistakes', () => {
  const result = classifyLocalError('我把图像和 y 轴交点看成了 x 的值，所以代入错了')

  assert.equal(result.tag, '图像理解错误')
  assert.match(result.reason, /图像|坐标/)
})

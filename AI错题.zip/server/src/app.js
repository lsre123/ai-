import Busboy from 'busboy'

import {
  buildCorrectionCardPayload,
  buildDiagnosis,
  buildProfile,
  buildVariantQuestion,
  loadStoredCards
} from './analytics.js'
import { buildCorrectionCard, buildMockFollowUp, buildMockPhotoResult, buildMockTutorReply } from './prompt.js'
import {
  hasCozeChatConfig,
  hasCozeConfig,
  hasCozeWorkflowConfig,
  runCozePhotoWorkflow,
  sendCozeChat
} from './cozeClient.js'

function createResponse(statusCode, payload, headers = {}) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
      ...headers
    },
    body: JSON.stringify(payload)
  }
}

async function readRequestBody(request) {
  const chunks = []
  for await (const chunk of request) chunks.push(chunk)
  const raw = Buffer.concat(chunks).toString('utf8')
  return raw ? JSON.parse(raw) : {}
}

function parseMultipartRequest(request) {
  return new Promise((resolve, reject) => {
    const busboy = Busboy({ headers: request.headers })
    const fields = {}
    let imageFile = null

    busboy.on('file', (name, stream, info) => {
      const chunks = []
      stream.on('data', (chunk) => chunks.push(chunk))
      stream.on('end', () => {
        if (name === 'question_image') {
          imageFile = {
            imageBuffer: Buffer.concat(chunks),
            fileName: info.filename || 'question.jpg',
            mimeType: info.mimeType || 'image/jpeg'
          }
        }
      })
    })

    busboy.on('field', (name, value) => {
      fields[name] = value
    })

    busboy.on('error', reject)
    busboy.on('finish', () => {
      resolve({
        ...fields,
        ...(imageFile || {})
      })
    })

    request.pipe(busboy)
  })
}

export function createApp({ env = process.env, fetchImpl = fetch } = {}) {
  const aiMode = hasCozeConfig(env) ? 'coze' : 'mock'

  async function route({ method, url, body = {} }) {
    const requestUrl = new URL(url, 'http://localhost')
    const pathname = requestUrl.pathname

    if (method === 'OPTIONS') {
      return createResponse(204, {})
    }

    if (method === 'GET' && pathname === '/api/health') {
      return createResponse(200, {
        ok: true,
        aiMode,
        service: 'ai-math-tutor'
      })
    }

    if (method === 'POST' && pathname === '/api/chat') {
      const reply = hasCozeChatConfig(env)
        ? await sendCozeChat({ env, fetchImpl, ...body })
        : buildMockTutorReply(body)

      return createResponse(200, {
        mode: aiMode,
        reply,
        card: buildCorrectionCardPayload(body)
      })
    }

    if (method === 'POST' && (
      pathname === '/api/photo-solve' ||
      pathname === '/api/photo-solve-upload' ||
      pathname === '/api/photo-analyze'
    )) {
      if (!body.imageBase64 && !body.imageBuffer) {
        return createResponse(400, {
          error: 'imageBase64 or imageBuffer is required'
        })
      }

      const mockResult = buildMockPhotoResult({
        studentNote: body.studentNote,
        unit: body.unit || env.TUTOR_UNIT_NAME || '一次函数'
      })
      const result = hasCozeWorkflowConfig(env)
        ? await runCozePhotoWorkflow({ env, fetchImpl, ...body })
        : mockResult

      const alignedDraft = buildCorrectionCard({
        question: result.questionText || mockResult.card.question,
        studentAnswer: result.studentWorkText || body.studentNote || '',
        knowledgePoint: result.knowledgePoint || mockResult.card.knowledgePoint
      })
      const card = {
        ...alignedDraft,
        question: result.questionText || alignedDraft.question,
        knowledgePoint: result.knowledgePoint || alignedDraft.knowledgePoint,
        errorTag: result.errorTag || alignedDraft.errorTag,
        errorReason: result.analysis || alignedDraft.errorReason,
        guidingQuestion: result.firstQuestion || alignedDraft.guidingQuestion,
        correctThinking: result.correctionCard?.correctThinking || alignedDraft.correctThinking,
        correctionTip: result.correctionCard?.tip || alignedDraft.correctionTip,
        nextPractice: result.correctionCard?.nextPractice || alignedDraft.nextPractice
      }

      const payload = {
        mode: hasCozeWorkflowConfig(env) ? 'coze' : 'mock',
        result,
        card
      }

      if (pathname === '/api/photo-analyze') {
        return createResponse(200, {
          ...payload,
          questionId: result.questionId || `q_${Date.now()}`,
          questionText: result.questionText || mockResult.questionText,
          studentAnswer: result.studentWorkText || mockResult.studentWorkText,
          knowledgePoint: result.knowledgePoint || mockResult.knowledgePoint,
          initialErrorType: result.errorTag || mockResult.errorTag,
          firstQuestion: result.firstQuestion || mockResult.firstQuestion
        })
      }

      return createResponse(200, payload)
    }

    if (method === 'POST' && pathname === '/api/follow-up') {
      const followUp = buildMockFollowUp(body)

      return createResponse(200, {
        mode: hasCozeChatConfig(env) ? 'coze-ready' : 'mock',
        hintLevel: Math.min(Math.max(Number(body.hintLevel || 1), 1), 4),
        ...followUp
      })
    }

    if (method === 'POST' && pathname === '/api/generate-card') {
      return createResponse(200, {
        mode: aiMode,
        card: buildCorrectionCardPayload(body)
      })
    }

    if (method === 'POST' && pathname === '/api/diagnosis') {
      const diagnosis = buildDiagnosis(body)

      return createResponse(200, {
        mode: aiMode,
        diagnosis,
        ...diagnosis
      })
    }

    if (method === 'POST' && pathname === '/api/correction-card') {
      const card = buildCorrectionCardPayload(body)

      return createResponse(200, {
        mode: aiMode,
        card,
        ...card
      })
    }

    if (method === 'POST' && pathname === '/api/variant-question') {
      const variant = buildVariantQuestion(body)

      return createResponse(200, {
        mode: aiMode,
        ...variant
      })
    }

    if (method === 'GET' && pathname === '/api/profile') {
      const storedCards = loadStoredCards()

      return createResponse(200, {
        mode: aiMode,
        userId: requestUrl.searchParams.get('userId') || 'demo_user',
        ...buildProfile(storedCards)
      })
    }

    return createResponse(404, {
      error: 'Not found'
    })
  }

  return {
    async handle(request, response) {
      try {
        const contentType = request.headers['content-type'] || ''
        const body = request.method === 'POST'
          ? contentType.includes('multipart/form-data')
            ? await parseMultipartRequest(request)
            : await readRequestBody(request)
          : {}
        const result = await route({
          method: request.method,
          url: request.url,
          body
        })

        response.writeHead(result.statusCode, result.headers)
        response.end(result.body)
      } catch (error) {
        const result = createResponse(500, {
          error: error.message || 'Server error',
          hint: error.message?.includes('access token invalid')
            ? 'Coze API Token 无效或已过期，请在 Coze API 管理中重新生成 Token 并更新 server/.env。'
            : undefined
        })
        response.writeHead(result.statusCode, result.headers)
        response.end(result.body)
      }
    },
    async inject({ method = 'GET', url = '/', body = {} }) {
      return route({ method, url, body })
    }
  }
}

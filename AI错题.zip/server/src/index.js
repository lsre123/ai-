import { createServer } from 'node:http'

import { createApp } from './app.js'

const port = Number(process.env.PORT || 3000)
const app = createApp()
const server = createServer(app.handle)

server.listen(port, () => {
  console.log(`AI math tutor server running at http://127.0.0.1:${port}`)
})

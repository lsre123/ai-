const DEFAULT_UNIT = '一次函数'

const ERROR_PATTERNS = [
  {
    tag: '图像理解错误',
    keywords: ['图像', '坐标', 'y轴', 'x轴', '交点', '斜率', '截距'],
    reason: '学生可能把图像、坐标轴或交点含义混在一起，需要先回到图像和坐标的对应关系。'
  },
  {
    tag: '公式或方法误用',
    keywords: ['公式', '方法', '代入', '方程', '函数式', '表达式'],
    reason: '学生可能知道相关方法，但使用位置或代入对象不准确。'
  },
  {
    tag: '计算错误',
    keywords: ['算错', '计算', '加', '减', '乘', '除', '=', '得数'],
    reason: '学生的思路可能接近正确，但运算过程需要逐步核对。'
  },
  {
    tag: '审题遗漏条件',
    keywords: ['条件', '已知', '题目', '没有看', '忽略', '单位'],
    reason: '学生可能漏读了题目条件，需要先标出已知量和所求量。'
  },
  {
    tag: '概念理解错误',
    keywords: ['不懂', '概念', '为什么', '意思', '关系', '函数'],
    reason: '学生可能对核心概念的含义还不稳定，需要用简单例子重新建立理解。'
  }
]

export function buildTutorSystemPrompt({ unitName = DEFAULT_UNIT } = {}) {
  return [
    `你是一名面向初中生的数学错题追问式AI学伴，当前重点单元是“${unitName}”。`,
    '你的目标不是替学生完成作业，而是帮助学生发现自己的思维漏洞。',
    '规则：',
    '1. 前两轮不得直接给出最终答案或完整解题过程。',
    '2. 每次只提出一个追问或一个小提示。',
    '3. 先询问学生已有思路，再判断可能错因。',
    '4. 语言要适合初中生，亲切、简洁、具体。',
    '5. 如果学生连续两次无法推进，可以给更明确的步骤提示。',
    '6. 最后必须要求学生用自己的话总结错因。',
    '7. 生成订正卡时，需要包含知识点、错因、正确思路、易错提醒和同类练习。'
  ].join('\n')
}

export function classifyLocalError(text = '') {
  const normalized = String(text).toLowerCase()
  const matched = ERROR_PATTERNS.find((item) =>
    item.keywords.some((keyword) => normalized.includes(keyword.toLowerCase()))
  )

  return matched ?? {
    tag: '步骤表达不完整',
    reason: '学生当前表达的信息还不够完整，需要先让学生说清楚每一步是怎么想的。'
  }
}

export function buildTutorInput({ question = '', studentAnswer = '', messages = [] } = {}) {
  const latestMessage = messages.at(-1)?.content ?? ''
  const studentText = [studentAnswer, latestMessage].filter(Boolean).join('\n')
  const error = classifyLocalError(`${question}\n${studentText}`)

  return {
    question: String(question).trim(),
    studentAnswer: String(studentAnswer).trim(),
    latestMessage: String(latestMessage).trim(),
    error
  }
}

export function buildMockTutorReply(input) {
  const { question, studentAnswer, latestMessage, error } = buildTutorInput(input)
  const hasStudentThinking = Boolean(studentAnswer || latestMessage)

  if (!question) {
    return '先把错题题干发给我吧。最好再补一句：你当时是从哪一步开始不确定的？'
  }

  if (!hasStudentThinking) {
    return '我先不直接讲答案。你能先说说：这道题里哪些是已知条件，题目最后要你求什么？'
  }

  if (error.tag === '图像理解错误') {
    return '我们先盯住图像读数这一点：你说的那个点，横坐标表示什么，纵坐标又表示什么？先各用一句话说出来。'
  }

  if (error.tag === '计算错误') {
    return '你的思路可能已经接近了。先把关键代入那一步单独写出来：把哪个数代到哪个位置？'
  }

  if (error.tag === '公式或方法误用') {
    return '先别急着套公式。你能说说为什么这一步要用这个方法吗？它和题目里的哪个条件对应？'
  }

  if (error.tag === '审题遗漏条件') {
    return '我们先重新审题：请你把题目中的已知条件圈出来，并告诉我哪一个条件还没有用上。'
  }

  return '先把你的第一步想法说具体一点：你是根据哪个知识点做出这个判断的？'
}

export function buildQuestionAlignedCardFields({
  question = '',
  knowledgePoint = '',
  difficulty = 'same'
} = {}) {
  const questionContext = cleanAiText(question)
  const stem = getQuestionStem(questionContext)
  const options = extractOptions(questionContext)
  const correctChoice = inferCorrectChoice(questionContext)
  const abbreviation = detectComputerAssistedAbbreviation(stem)
  const isChoiceQuestion = options.length >= 2 || correctChoice

  if (abbreviation && correctChoice) {
    const practiceTopic = abbreviation.practice
    const distractors = ['计算机辅助设计', '计算机辅助教学', '计算机辅助制造', '计算机辅助管理']
      .filter((item) => item !== practiceTopic.answer)
    const nextPractice = `同类练习：${practiceTopic.abbr} 的中文意思是？A）${practiceTopic.answer} B）${distractors[0]} C）${distractors[1]} D）${distractors[2]}。先写出 ${practiceTopic.letter} 对应的英文含义再选择。`

    return {
      knowledgePoint: knowledgePoint || '计算机应用',
      correctThinking: `先抓题干中的缩写 ${abbreviation.abbr}，再看关键字母 ${abbreviation.letter} = ${abbreviation.english}（${abbreviation.meaning}），所以对应“${correctChoice.text}”。`,
      correctionTip: `把常见计算机辅助类缩写按“缩写-英文关键词-中文含义”整理：${abbreviation.abbr} 的 ${abbreviation.letter} 是 ${abbreviation.english}，不要和 CAI、CAM 混淆。`,
      nextPractice,
      variantQuestion: nextPractice.replace('同类练习：', difficulty === 'harder' ? '同断点提升题：' : '同断点变式题：'),
      reflectionPrompt: '请用自己的话写一句：我下次看到这类英文缩写时，先检查哪个关键字母？'
    }
  }

  if (/最早/.test(stem) && correctChoice) {
    const nextPractice = '同类练习：早期计算机最主要的应用领域是？A）数值计算 B）办公自动化 C）辅助教学 D）娱乐应用。先圈出“早期/最主要”，再判断选项。'

    return {
      knowledgePoint: knowledgePoint || '计算机应用领域',
      correctThinking: `先抓关键词“最早”，早期计算机首先用于大量计算，所以应对应“${correctChoice.text}”。`,
      correctionTip: '遇到“最早、最初、主要用途”这类题，先看时间或范围限制，再和选项含义逐一对应。',
      nextPractice,
      variantQuestion: nextPractice.replace('同类练习：', difficulty === 'harder' ? '同断点提升题：' : '同断点变式题：'),
      reflectionPrompt: '请用自己的话写一句：这类题我下次先看哪个限定词？'
    }
  }

  if (isChoiceQuestion) {
    const target = correctChoice ? `“${correctChoice.text}”` : '最符合题干关键词的选项'
    const nextPractice = `同类练习：仿照本题，先圈出题干关键词，再把每个选项和关键词逐一对应，最后选出${target}。`

    return {
      knowledgePoint: knowledgePoint || '选择题审题',
      correctThinking: `先圈出题干关键词“${stem || '题干条件'}”，再逐项比对选项含义，选出最贴合题意的一项。`,
      correctionTip: '选择题不要只凭熟悉词作答，先把题干关键词和每个选项的含义对应起来。',
      nextPractice,
      variantQuestion: nextPractice.replace('同类练习：', difficulty === 'harder' ? '同断点提升题：' : '同断点变式题：'),
      reflectionPrompt: '请用自己的话写一句：这道选择题我下次最需要先看什么？'
    }
  }

  return {
    knowledgePoint: knowledgePoint || '一次函数',
    correctThinking: '先确认题目给出的条件和所求问题，再把对应的数值代入正确位置，逐步计算并检查结果。',
    correctionTip: '把已知条件、所求问题和关键步骤分开写，先说明依据，再进行计算。',
    nextPractice: '同类练习：已知一次函数 y = 3x - 2，求 x = 4 时 y 的值，并说明每一步的依据。',
    variantQuestion: difficulty === 'harder'
      ? '同断点提升题：已知一次函数图像经过 A(1, 3)、B(4, 9)，请先列出两个方程，再求函数表达式，并说明每一步依据。'
      : '同断点变式题：已知一次函数 y = 3x - 2，求 x = 4 时 y 的值，并写出代入位置和计算过程。',
    reflectionPrompt: '请用自己的话写一句：这道题我下次最需要注意什么？'
  }
}

export function buildCorrectionCard(input) {
  const { question, studentAnswer, error } = buildTutorInput(input)
  const aligned = buildQuestionAlignedCardFields({
    question,
    knowledgePoint: input?.knowledgePoint
  })

  return {
    title: '错题订正卡',
    question,
    knowledgePoint: aligned.knowledgePoint,
    errorTag: error.tag,
    errorReason: error.reason,
    originalThinking: studentAnswer || '学生暂未留下完整原思路，可结合追问过程补充当时为什么这样想。',
    guidingQuestion: buildMockTutorReply(input),
    correctThinking: aligned.correctThinking,
    correctionTip: aligned.correctionTip,
    nextPractice: aligned.nextPractice,
    reflectionPrompt: aligned.reflectionPrompt
  }
}

export function buildMockPhotoResult({
  studentNote = '',
  unit = DEFAULT_UNIT
} = {}) {
  const questionText = `已知一次函数 y = 2x + 1，求 x = 3 时 y 的值。`
  const studentWorkText = studentNote || '学生可能把 x 的值直接加到常数项后面。'
  const card = buildCorrectionCard({
    question: questionText,
    studentAnswer: studentWorkText
  })

  return {
    questionText,
    studentWorkText,
    knowledgePoint: unit,
    errorTag: card.errorTag,
    analysis: card.errorReason,
    firstQuestion: card.guidingQuestion,
    correctionCard: {
      title: card.title,
      correctThinking: '先确认函数表达式，再把 x = 3 代入 2x + 1 中计算。',
      tip: card.correctionTip,
      nextPractice: card.nextPractice
    },
    card: {
      ...card,
      knowledgePoint: unit
    }
  }
}

export function buildMockFollowUp({ analysis = {}, messages = [] } = {}) {
  const studentMessages = messages.filter((message) => message.role === 'student')
  const lastStudent = studentMessages.at(-1)?.content || ''
  const lastAssistant = messages.filter((message) => message.role === 'assistant').at(-1)?.content || ''
  const knowledgePoint = analysis.knowledgePoint || '当前知识点'
  const errorTag = analysis.errorTag || '当前错因'
  const questionText = cleanAiText(analysis.questionText || '')
  const fallbackQuestionText = cleanAiText(`${analysis.questionText || ''}\n${analysis.studentWorkText || ''}`)
  const questionContext = questionText || fallbackQuestionText
  const options = extractOptions(questionContext)
  const correctChoice = inferCorrectChoice(questionContext)
  const originalWrongChoice = extractStudentChoice(analysis.studentWorkText || '', options)
  const simpleConceptChoice = isSimpleConceptChoice(questionContext)
  const wantsDirectAnswer = /答案是什么|选什么|选哪|直接告诉|不会选|是哪一个|哪个选项|正确选项|what.*answer|which option/i.test(lastStudent)
  const latestChoice = extractStudentChoice(lastStudent, options)
  const previousChoice = findLatestStudentChoice(studentMessages.slice(0, -1), options)
  const assistantConfirmedChoice = correctChoice && /答案对|答对|方向对|选[A-DＡ-Ｄ]对|这个答案对/.test(lastAssistant)
    ? correctChoice.label
    : ''
  const selectedChoice = latestChoice || previousChoice || assistantConfirmedChoice
  const isUnclear = !selectedChoice && (/不知道|不清楚|不会|不懂|随便|没有|无|不确定|不知道怎么/.test(lastStudent) || lastStudent.trim().length < 4)
  const hasExplicitConclusion = /所以|因此|应该|我知道|正确|答案|选[A-DＡ-Ｄ]|选项[A-DＡ-Ｄ]|错在|原因|下次|要注意|因为|依据|关键词|排除|answer should|should be|because|therefore|so |correct/i.test(lastStudent)
  const hasReflection = /错在|原因|下次|要注意|我应该|我需要|没记牢|记错|记混|混淆|先看|关键词|概念|条件|依据|规则|wrong|mistake|next time|need to|because|rule|concept/i.test(lastStudent)
  const hasMistakeSummary = /错在|下次|要注意|我应该|我需要|没记牢|记错|记混|混淆|先看|关键词|概念|条件|依据|规则|wrong|mistake|next time|need to|rule|concept/i.test(lastStudent)
  const asksEarliest = /最早/.test(`${questionContext}\n${lastStudent}`)
  const isChoiceQuestion = options.length >= 2 || /A[）).]|B[）).]|C[）).]|D[）).]|选项/.test(questionContext)
  const selectedCorrectChoice = Boolean(correctChoice && selectedChoice === correctChoice.label)
  const selectedWrongChoice = Boolean(correctChoice && latestChoice && latestChoice !== correctChoice.label)
  const mentionsCorrectChoice = Boolean(
    correctChoice &&
      (selectedCorrectChoice || cleanAiText(lastStudent).includes(correctChoice.text) || lastStudent.includes(`选${correctChoice.label}`))
  )
  const givesReason = /因为|理由|原因|最早|用于|用来|主要|计算|关键词|依据|不是|而是|意思|表示|等于|就是|design|instruction|manufacturing|because|why/i.test(lastStudent)
  const choicePrompt = buildChoicePrompt({
    asksEarliest,
    correctChoice,
    selectedWrongChoice,
    selectedChoice,
    lastStudent
  })

  function avoidRepeat(reply, fallback) {
    return reply === lastAssistant ? fallback : reply
  }

  if (isChoiceQuestion && selectedWrongChoice) {
    return {
      stage: 'guide',
      canFinish: false,
      reply: avoidRepeat(
        choicePrompt,
        correctChoice
          ? `再看题干的关键限制。“${correctChoice.text}”更符合题意。你重新说：这题选哪项？为什么？`
          : '你这个选项还不稳。先回到题干关键词，再重新判断选哪项。'
      )
    }
  }

  if (isChoiceQuestion && correctChoice && selectedChoice && selectedChoice !== correctChoice.label && givesReason) {
    return {
      stage: 'guide',
      canFinish: false,
      reply: avoidRepeat(
        buildChoicePrompt({
          asksEarliest,
          correctChoice,
          selectedWrongChoice: true,
          selectedChoice
        }),
        `你现在的理由更接近${correctChoice.label}“${correctChoice.text}”。请重新说出正确选项。`
      )
    }
  }

  if (isChoiceQuestion && correctChoice && latestChoice === correctChoice.label && !givesReason) {
    return {
      stage: 'guide',
      canFinish: false,
      reply: avoidRepeat(
        buildCorrectChoiceReasonPrompt({ correctChoice, questionContext }),
        `对，是${correctChoice.label}“${correctChoice.text}”。现在只补一句理由。`
      )
    }
  }

  if (isChoiceQuestion && correctChoice && mentionsCorrectChoice && givesReason && !hasMistakeSummary) {
    if (simpleConceptChoice) {
      return {
        stage: 'finish',
        canFinish: true,
        reply: avoidRepeat(
          `可以了。你已经说清楚答案和理由，现在可以生成订正卡。`,
          '可以生成订正卡了。'
        ),
        summary: lastStudent
      }
    }

    return {
      stage: 'summary',
      canFinish: false,
      reply: avoidRepeat(
        buildMistakePrompt({ correctChoice, lastStudent, options, originalWrongChoice }),
        '答案和理由都对了。最后说一句：刚才为什么会错？下次先看什么？'
      )
    }
  }

  if (isChoiceQuestion && correctChoice && mentionsCorrectChoice && givesReason && hasMistakeSummary) {
    return {
      stage: 'finish',
      canFinish: true,
      reply: avoidRepeat(
        `可以了。你已经说清楚正确答案和错因。现在可以生成订正卡。`,
        '可以生成订正卡了。'
      ),
      summary: lastStudent
    }
  }

  if (isChoiceQuestion && selectedChoice && !correctChoice && !givesReason) {
    const selectedOption = options.find((option) => option.label === selectedChoice)
    return {
      stage: 'guide',
      canFinish: false,
      reply: avoidRepeat(
        `我看到了，你答的是${selectedOption ? `${selectedChoice}“${selectedOption.text}”` : selectedChoice}。先别改答案，补一句理由：题干里的哪个词让你这样选？`,
        `你已经作答了。现在只补一句理由。`
      )
    }
  }

  if (isChoiceQuestion && selectedChoice && !correctChoice && givesReason && !hasMistakeSummary) {
    return {
      stage: 'summary',
      canFinish: false,
      reply: avoidRepeat(
        `你已经说了选${selectedChoice}和理由。最后补一句：刚才为什么会错？下次先看什么？`,
        '还差错因总结：我错在__，下次先看__。'
      )
    }
  }

  if (isChoiceQuestion && selectedChoice && !correctChoice && givesReason && hasMistakeSummary) {
    return {
      stage: 'finish',
      canFinish: true,
      reply: avoidRepeat(
        '可以了。你已经说清楚选项、理由和错因。现在可以生成订正卡。',
        '可以生成订正卡了。'
      ),
      summary: lastStudent
    }
  }

  if (wantsDirectAnswer) {
    return {
      stage: 'guide',
      canFinish: false,
      reply: isChoiceQuestion
        ? avoidRepeat(
            choicePrompt,
            '我先不给你直接抄答案。先看题干关键词，再选一个最符合的选项。'
          )
        : avoidRepeat(
            `先抓要害：这题考“${knowledgePoint}”。你先说题目要你求什么。`,
            '先不看答案。你只说：题目最后问什么？'
          )
    }
  }

  if (!isChoiceQuestion && hasExplicitConclusion && hasReflection && !wantsDirectAnswer && !isUnclear) {
    return {
      stage: 'finish',
      canFinish: true,
      reply: avoidRepeat(
        `可以了。你已经说清楚答案和错因：${errorTag}。现在可以生成订正卡。`,
        '可以生成订正卡了。'
      ),
      summary: lastStudent
    }
  }

  if (!isChoiceQuestion && hasExplicitConclusion && !hasReflection && !wantsDirectAnswer) {
    return {
      stage: 'summary',
      canFinish: false,
      reply: avoidRepeat(
        '答案方向有了。现在补一句错因：你刚才卡在哪里？下次要先看什么？',
        '用一句话收尾：我错在__，下次先__。'
      )
    }
  }

  if (hasReflection && !hasExplicitConclusion && isChoiceQuestion) {
    return {
      stage: 'guide',
      canFinish: false,
      reply: avoidRepeat(
        choicePrompt,
        '你已经说出错因了。现在回到题干，重新判断正确选项。'
      )
    }
  }

  if (isUnclear) {
    return {
      stage: 'guide',
      canFinish: false,
      reply: avoidRepeat(
        isChoiceQuestion
          ? choicePrompt
          : `我给你缩小一步：这题先看“${knowledgePoint}”。题目让你求什么？`,
        asksEarliest ? '先看关键词“最早”。哪个选项最像早期计算机的主要用途？' : '先看题干关键词，再看选项。'
      )
    }
  }

  if (studentMessages.length >= 1) {
    return {
      stage: 'guide',
      canFinish: false,
      reply: avoidRepeat(
        isChoiceQuestion
          ? choicePrompt
          : `再具体一点：你这一步的依据是什么？`,
        '先别展开太多。只说这一步为什么这样做。'
      )
    }
  }

  return {
    stage: 'question',
    canFinish: false,
    reply: avoidRepeat(
      analysis.firstQuestion || '你先说说：你觉得自己是从哪一步开始不确定的？',
      isChoiceQuestion ? choicePrompt : '你先说题目最后问什么。'
    )
  }
}

function extractSelectedChoice(text = '') {
  const trimmed = String(text).trim()
  if (/^[A-DＡ-Ｄ]$/i.test(trimmed)) {
    return trimmed
      .toUpperCase()
      .replace('Ａ', 'A')
      .replace('Ｂ', 'B')
      .replace('Ｃ', 'C')
      .replace('Ｄ', 'D')
  }

  const match = trimmed.match(/(?:选|答案是|应该是|我选|选项)\s*([A-DＡ-Ｄ])\b/i)
  if (!match) return ''
  return match[1]
    .toUpperCase()
    .replace('Ａ', 'A')
    .replace('Ｂ', 'B')
    .replace('Ｃ', 'C')
    .replace('Ｄ', 'D')
}

function extractStudentChoice(text = '', options = []) {
  return extractSelectedChoice(text) || findOptionByText(text, options)?.label || ''
}

function findLatestStudentChoice(studentMessages = [], options = []) {
  for (let index = studentMessages.length - 1; index >= 0; index -= 1) {
    const choice = extractStudentChoice(studentMessages[index]?.content || '', options)
    if (choice) return choice
  }
  return ''
}

function cleanAiText(text = '') {
  return String(text)
    .replace(/未识别到明显作答/g, '')
    .replace(/未明确作答选项，?暂无法判断具体错因/g, '')
    .replace(/图片中未识别到明显解题过程/g, '')
    .replace(/学生选择(?:了|为)?\s*[A-DＡ-Ｄ]?/g, '')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{2,}/g, '\n')
    .trim()
}

function extractOptions(questionText = '') {
  const text = cleanAiText(questionText)
  const optionMatches = [...text.matchAll(/([A-DＡ-Ｄ])\s*[）).、:：]\s*([\s\S]*?)(?=\s*[A-DＡ-Ｄ]\s*[）).、:：]|$)/g)]

  return optionMatches
    .map((match) => ({
      label: match[1]
        .toUpperCase()
        .replace('Ａ', 'A')
        .replace('Ｂ', 'B')
        .replace('Ｃ', 'C')
        .replace('Ｄ', 'D'),
      text: cleanAiText(match[2]).replace(/[。；;，,]*$/, '').trim()
    }))
    .filter((option) => option.text)
}

function normalizeAnswerText(text = '') {
  return cleanAiText(text)
    .toLowerCase()
    .replace(/[（）()、:：，,。.;；\s]/g, '')
}

function findOptionByText(text = '', options = []) {
  const normalizedText = normalizeAnswerText(text)
  if (!normalizedText) return null

  return options.find((option) => {
    const normalizedOption = normalizeAnswerText(option.text)
    return normalizedOption && (
      normalizedText === normalizedOption ||
      normalizedText.includes(normalizedOption) ||
      normalizedOption.includes(normalizedText)
    )
  }) || null
}

function inferCorrectChoice(questionText = '') {
  const text = cleanAiText(questionText)
  const stem = getQuestionStem(text)
  const options = extractOptions(text)

  if (/最早/.test(stem)) {
    const numericOption = options.find((option) => /数值计算|科学计算/.test(option.text))
    if (numericOption) return numericOption
  }

  if (/\bCAI\b|计算机辅助教学|辅助教学/i.test(stem)) {
    const caiOption = options.find((option) => /计算机辅助教学|辅助教学/.test(option.text))
    if (caiOption) return caiOption
  }

  if (/\bCAD\b|计算机辅助设计|辅助设计/i.test(stem)) {
    const cadOption = options.find((option) => /计算机辅助设计|辅助设计/.test(option.text))
    if (cadOption) return cadOption
  }

  if (/\bCAM\b|计算机辅助制造|辅助制造/i.test(stem)) {
    const camOption = options.find((option) => /计算机辅助制造|辅助制造/.test(option.text))
    if (camOption) return camOption
  }

  return null
}

function getQuestionStem(text = '') {
  return cleanAiText(text).split(/[A-DＡ-Ｄ]\s*[）).、:：]/)[0] || ''
}

function isSimpleConceptChoice(questionContext = '') {
  const stem = getQuestionStem(questionContext)
  return /\b(CAD|CAI|CAM)\b|计算机辅助设计|计算机辅助教学|计算机辅助制造|辅助设计|辅助教学|辅助制造/i.test(stem)
}

function detectComputerAssistedAbbreviation(stem = '') {
  const topics = [
    {
      abbr: 'CAD',
      letter: 'D',
      english: 'Design',
      meaning: '设计',
      answer: '计算机辅助设计'
    },
    {
      abbr: 'CAI',
      letter: 'I',
      english: 'Instruction',
      meaning: '教学',
      answer: '计算机辅助教学'
    },
    {
      abbr: 'CAM',
      letter: 'M',
      english: 'Manufacturing',
      meaning: '制造',
      answer: '计算机辅助制造'
    }
  ]
  const matched = topics.find((topic) =>
    new RegExp(`\\b${topic.abbr}\\b`, 'i').test(stem) ||
    stem.includes(topic.answer) ||
    stem.includes(topic.answer.replace('计算机', ''))
  )

  if (!matched) return null

  const practice = topics.find((topic) => topic.abbr !== matched.abbr) || matched
  return {
    ...matched,
    practice
  }
}

function buildCorrectChoiceReasonPrompt({ correctChoice, questionContext }) {
  const stem = getQuestionStem(questionContext)

  if (/\bCAD\b|辅助设计/i.test(stem)) {
    return `这个答案对。关键点是 CAD 里的 D 表示 Design，也就是“设计”。现在请你用自己的话补一句理由：为什么是${correctChoice.text}？`
  }

  if (/\bCAI\b|辅助教学/i.test(stem)) {
    return `这个答案对。关键点是 CAI 里的 I 表示 Instruction，也就是“教学”。现在请你用自己的话补一句理由：为什么是${correctChoice.text}？`
  }

  if (/最早/.test(stem)) {
    return `选${correctChoice.label}对了。关键是“最早”：早期计算机主要用来做大量计算。现在请你用自己的话说一句理由。`
  }

  return `答对了。请补一句理由：题干里的哪个词，能说明它对应“${correctChoice.text}”？`
}

function buildMistakePrompt({ correctChoice, lastStudent, options = [], originalWrongChoice = '' }) {
  if (/\bCAD\b|辅助设计|design/i.test(lastStudent)) {
    return `答案和理由都对了。最后补错因：你刚才是不是把 CAD 的含义和别的缩写记混了？用自己的话说一遍。`
  }

  if (/\bCAI\b|辅助教学|instruction/i.test(lastStudent)) {
    return `答案和理由都对了。最后补错因：你刚才是不是把 CAI 的含义和别的缩写记混了？用自己的话说一遍。`
  }

  if (/大量计算|数值计算|早期计算机|最早/.test(lastStudent)) {
    const wrongOption = options.find((option) =>
      option.label === originalWrongChoice && option.label !== correctChoice?.label
    )
    const wrongText = wrongOption?.text || '其他用途'
    return `这句理由可以。最后补错因：你刚才是不是把“${wrongText}”和“最早用途”混在一起了？用自己的话说一遍。`
  }

  return `答案和方向都对了。最后补错因：你刚才为什么会没选${correctChoice.label}？下次先看哪个关键词？`
}

function buildChoicePrompt({
  asksEarliest,
  correctChoice,
  selectedWrongChoice,
  selectedChoice
}) {
  if (selectedWrongChoice && asksEarliest && correctChoice) {
    return `你选了${selectedChoice}，但这题的关键是“最早”。早期计算机首先是用来做大量计算的。再看${correctChoice.label}“${correctChoice.text}”，你觉得它是不是更符合？请重新说出正确选项。`
  }

  if (selectedWrongChoice) {
    return '你这个选项还不稳。先回到题干的关键词，再重新判断哪个选项最贴合。'
  }

  if (asksEarliest && correctChoice) {
    return `先看关键词“最早”。早期计算机最先解决的是大量计算问题。四个选项里，哪个写的是“${correctChoice.text}”？你先说选项。`
  }

  return '先看题干关键词。再看四个选项，哪一个和关键词最贴近？你先说选项。'
}

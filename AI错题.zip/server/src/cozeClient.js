import { buildTutorSystemPrompt } from './prompt.js'

const DEFAULT_COZE_BASE_URL = 'https://api.coze.cn'

export function hasCozeConfig(env = process.env) {
  return Boolean(env.COZE_API_TOKEN && (env.COZE_BOT_ID || env.COZE_WORKFLOW_ID))
}

export function hasCozeChatConfig(env = process.env) {
  return Boolean(env.COZE_API_TOKEN && env.COZE_BOT_ID)
}

export function hasCozeWorkflowConfig(env = process.env) {
  return Boolean(env.COZE_API_TOKEN && env.COZE_WORKFLOW_ID)
}

function extractContent(message) {
  if (!message) return ''
  if (typeof message === 'string') return message
  if (typeof message.content === 'string') return message.content
  if (Array.isArray(message.content)) {
    return message.content
      .map((part) => part?.text ?? part?.content ?? '')
      .filter(Boolean)
      .join('\n')
  }
  return ''
}

export function parseCozeReply(payload) {
  const data = payload?.data ?? payload
  const messageGroups = [
    data?.messages,
    data?.message_list,
    data?.output,
    payload?.messages
  ].filter(Array.isArray)

  for (const group of messageGroups) {
    const answer = group.find((item) =>
      ['assistant', 'answer'].includes(item?.role) || item?.type === 'answer'
    )
    const content = extractContent(answer)
    if (content) return content
  }

  return (
    extractContent(data?.message) ||
    extractContent(data?.answer) ||
    extractContent(data?.content) ||
    extractContent(payload?.answer) ||
    ''
  )
}

async function cozePost({ env, fetchImpl, path, body }) {
  const baseUrl = env.COZE_API_BASE_URL || DEFAULT_COZE_BASE_URL
  const response = await fetchImpl(`${baseUrl}${path}`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${env.COZE_API_TOKEN}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  })

  const text = await response.text()
  const payload = text ? JSON.parse(text) : {}

  if (!response.ok || (payload.code && payload.code !== 0)) {
    const message = payload.msg || payload.message || response.statusText
    throw new Error(`Coze request failed: ${message}`)
  }

  return payload
}

async function cozeUploadFile({
  env,
  fetchImpl,
  imageBase64,
  imageBuffer,
  fileName = 'question.jpg',
  mimeType = 'image/jpeg'
}) {
  const baseUrl = env.COZE_API_BASE_URL || DEFAULT_COZE_BASE_URL
  const cleanBase64 = String(imageBase64 || '').replace(/^data:[^;]+;base64,/, '')
  const bytes = imageBuffer ?? Buffer.from(cleanBase64, 'base64')
  const form = new FormData()
  form.append('file', new Blob([bytes], { type: mimeType }), fileName)

  const response = await fetchImpl(`${baseUrl}/v1/files/upload`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${env.COZE_API_TOKEN}`
    },
    body: form
  })

  const text = await response.text()
  const payload = text ? JSON.parse(text) : {}

  if (!response.ok || (payload.code && payload.code !== 0)) {
    const message = payload.msg || payload.message || response.statusText
    throw new Error(`Coze file upload failed: ${message}`)
  }

  const data = payload.data ?? payload
  const fileId = data.id || data.file_id || data.fileId
  if (!fileId) {
    throw new Error('Coze file upload did not return a file id.')
  }

  return fileId
}

function tryParseJson(value) {
  if (typeof value !== 'string') return value
  try {
    return JSON.parse(value)
  } catch {
    return value
  }
}

function cleanWorkflowText(value = '') {
  return String(value || '')
    .replace(/未识别到明显作答/g, '')
    .replace(/未明确作答选项，?暂无法判断具体错因/g, '')
    .replace(/图片中未识别到明显解题过程/g, '')
    .trim()
}

export function normalizePhotoWorkflowResult(payload, fallback = {}) {
  const rawData = payload?.data ?? payload
  const parsedData = tryParseJson(rawData)
  const output = tryParseJson(parsedData?.output ?? parsedData?.outputs ?? parsedData)
  const result = tryParseJson(output?.result ?? output?.data ?? output)

  return {
    questionText: cleanWorkflowText(result?.questionText || result?.question_text || fallback.questionText || ''),
    studentWorkText: cleanWorkflowText(result?.studentWorkText || result?.student_work_text || fallback.studentWorkText || ''),
    knowledgePoint: cleanWorkflowText(result?.knowledgePoint || result?.knowledge_point || fallback.knowledgePoint || '一次函数'),
    errorTag: cleanWorkflowText(result?.errorTag || result?.error_tag || fallback.errorTag || '步骤表达不完整'),
    analysis: cleanWorkflowText(result?.analysis || fallback.analysis || ''),
    firstQuestion: cleanWorkflowText(result?.firstQuestion || result?.first_question || fallback.firstQuestion || ''),
    correctionCard: result?.correctionCard || result?.correction_card || fallback.correctionCard || {}
  }
}

export async function runCozePhotoWorkflow({
  env = process.env,
  fetchImpl = fetch,
  imageBase64 = '',
  imageBuffer,
  fileName = 'question.jpg',
  mimeType = 'image/jpeg',
  studentNote = '',
  unit = '一次函数'
}) {
  const fileId = await cozeUploadFile({
    env,
    fetchImpl,
    imageBase64,
    imageBuffer,
    fileName,
    mimeType
  })

  const workflowPayload = await cozePost({
    env,
    fetchImpl,
    path: '/v1/workflow/run',
    body: {
      workflow_id: env.COZE_WORKFLOW_ID,
      parameters: {
        question_image: JSON.stringify({ file_id: fileId }),
        student_note: studentNote,
        grade: '初中',
        unit
      }
    }
  })

  return normalizePhotoWorkflowResult(workflowPayload, {
    knowledgePoint: unit
  })
}

export async function sendCozeChat({
  env = process.env,
  fetchImpl = fetch,
  userId = 'local-student',
  question = '',
  studentAnswer = '',
  messages = []
}) {
  const userContent = [
    `题目：${question}`,
    studentAnswer ? `学生原始思路：${studentAnswer}` : '',
    messages.length ? `最近对话：${messages.map((item) => `${item.role}: ${item.content}`).join('\n')}` : '',
    '请按照追问式学伴规则回复。'
  ].filter(Boolean).join('\n\n')

  const chatPayload = await cozePost({
    env,
    fetchImpl,
    path: '/v3/chat',
    body: {
      bot_id: env.COZE_BOT_ID,
      user_id: userId,
      stream: false,
      auto_save_history: true,
      additional_messages: [
        {
          role: 'system',
          content: buildTutorSystemPrompt({ unitName: env.TUTOR_UNIT_NAME || '一次函数' }),
          content_type: 'text'
        },
        {
          role: 'user',
          content: userContent,
          content_type: 'text'
        }
      ]
    }
  })

  const directReply = parseCozeReply(chatPayload)
  if (directReply) return directReply

  const data = chatPayload.data ?? {}
  const chatId = data.id || data.chat_id
  const conversationId = data.conversation_id

  if (!chatId || !conversationId) {
    throw new Error('Coze response did not include an answer, chat_id, or conversation_id.')
  }

  for (let attempt = 0; attempt < 8; attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, 700))

    const messagesPayload = await cozePost({
      env,
      fetchImpl,
      path: '/v3/chat/message/list',
      body: {
        chat_id: chatId,
        conversation_id: conversationId
      }
    })

    const reply = parseCozeReply(messagesPayload)
    if (reply) return reply
  }

  throw new Error('Coze did not return an answer before the local timeout.')
}

import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

import { buildCorrectionCard, buildQuestionAlignedCardFields, classifyLocalError } from './prompt.js'

const BREAKPOINT_RULES = [
  { pattern: /审题|条件|题目|遗漏|漏/, name: '条件提取断点' },
  { pattern: /图像|坐标|交点|斜率|读图/, name: '读图断点' },
  { pattern: /公式|方法|建模|函数式|表达式|列式/, name: '建模断点' },
  { pattern: /计算|代入|得数|运算|算/, name: '运算断点' },
  { pattern: /检验|验证|实际意义/, name: '检验断点' },
  { pattern: /表达|步骤|完整|书写/, name: '表达断点' }
]

const DEFAULT_CARDS = [
  {
    id: 'demo-card-1',
    knowledgePoint: '一次函数',
    errorTag: '建模错误',
    breakpoint: '建模断点',
    question: '已知一次函数经过两个点，求函数表达式。',
    studentSummary: '我没有先把点的坐标转成方程。',
    createdAt: new Date().toISOString()
  },
  {
    id: 'demo-card-2',
    knowledgePoint: '一次函数',
    errorTag: '条件遗漏',
    breakpoint: '条件提取断点',
    question: '根据图像判断自变量和函数值的变化关系。',
    studentSummary: '我只看到了一个条件，漏掉了图像里的交点。',
    createdAt: new Date(Date.now() - 86400000).toISOString()
  }
]

function toArray(value) {
  return Array.isArray(value) ? value : []
}

function pickBreakpoint(errorTag = '') {
  const matched = BREAKPOINT_RULES.find((item) => item.pattern.test(errorTag))
  return matched?.name || '表达断点'
}

function countBy(items, getter) {
  const map = new Map()
  for (const item of items) {
    const key = getter(item)
    if (!key) continue
    map.set(key, (map.get(key) || 0) + 1)
  }
  return [...map.entries()]
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
}

function readJsonFile(filePath, fallback = []) {
  if (!existsSync(filePath)) return fallback
  try {
    return JSON.parse(readFileSync(filePath, 'utf8'))
  } catch {
    return fallback
  }
}

function isMathFunctionText(text = '') {
  return /一次函数|函数|x\s*=|y\s*=|代入|常数项|坐标|斜率/.test(String(text))
}

function isComputerApplicationText(text = '') {
  return /\b(CAD|CAI|CAM)\b|计算机辅助|辅助设计|辅助教学|辅助制造|数值计算|应用领域/i.test(String(text))
}

function pickOriginalThinking({
  question = '',
  studentAnswer = '',
  studentReply = '',
  analysisStudentWork = '',
  cardOriginalThinking = ''
} = {}) {
  const explicit = [studentAnswer, studentReply, analysisStudentWork]
    .map((item) => String(item || '').trim())
    .find(Boolean)
  if (explicit) return explicit

  const draft = String(cardOriginalThinking || '').trim()
  if (!draft) return ''

  if (isComputerApplicationText(question) && isMathFunctionText(draft)) {
    return ''
  }

  return draft
}

function pickDraftText({ question = '', value = '' } = {}) {
  const text = String(value || '').trim()
  if (!text) return ''
  if (isComputerApplicationText(question) && !isComputerApplicationText(text)) {
    return ''
  }
  if (isComputerApplicationText(question) && isMathFunctionText(text)) return ''
  return text
}

export function loadStoredCards() {
  const cardsPath = join(process.cwd(), 'data', 'cards.json')
  return readJsonFile(cardsPath, [])
}

export function buildDiagnosis(input = {}) {
  const analysis = input.analysis || {}
  const messages = toArray(input.messages || input.dialogueHistory)
  const studentText = [
    input.studentAnswer,
    input.studentReply,
    analysis.studentWorkText,
    ...messages.filter((item) => item.role === 'student').map((item) => item.content)
  ].filter(Boolean).join('\n')
  const question = input.question || analysis.questionText || ''
  const error = analysis.errorTag
    ? { tag: analysis.errorTag, reason: analysis.analysis || analysis.errorReason || '' }
    : classifyLocalError(`${question}\n${studentText}`)
  const mainBreakpoint = input.mainBreakpoint || pickBreakpoint(error.tag)
  const secondaryBreakpoint = input.secondaryBreakpoint || (
    mainBreakpoint === '建模断点' ? '条件提取断点' : '表达断点'
  )
  const hintLevel = Math.min(Math.max(Number(input.hintLevel || 1), 1), 4)

  return {
    questionId: input.questionId || analysis.questionId || `q_${Date.now()}`,
    mainBreakpoint,
    secondaryBreakpoint,
    errorType: error.tag,
    evidence: messages.length
      ? `系统依据 ${messages.length} 条追问记录判断：学生能表达部分思路，但在“${mainBreakpoint}”处需要继续拆解。`
      : error.reason || `学生当前信息显示主要卡在“${mainBreakpoint}”。`,
    suggestion: mainBreakpoint === '建模断点'
      ? '先圈出变化量和不变量，再把条件转成等式或函数关系。'
      : '把已知条件、所求问题和每一步依据分开写，最后主动检验答案是否符合题意。',
    hintLevel,
    processMap: [
      { name: '读题', active: mainBreakpoint === '读题断点' },
      { name: '条件提取', active: mainBreakpoint === '条件提取断点' },
      { name: '建模', active: mainBreakpoint === '建模断点' },
      { name: '计算', active: mainBreakpoint === '运算断点' },
      { name: '检验', active: mainBreakpoint === '检验断点' },
      { name: '表达', active: mainBreakpoint === '表达断点' }
    ]
  }
}

export function buildVariantQuestion(input = {}) {
  const breakpoint = input.breakpoint || input.mainBreakpoint || '建模断点'
  const difficulty = input.difficulty || 'same'
  const knowledgePoint = input.knowledgePoint || input.analysis?.knowledgePoint || '一次函数'
  const question = input.question || input.analysis?.questionText || input.card?.question || ''
  const aligned = buildQuestionAlignedCardFields({
    question,
    knowledgePoint,
    difficulty
  })
  const harder = difficulty === 'harder'

  return {
    variantQuestion: aligned.variantQuestion || (harder
      ? '同断点提升题：已知一次函数图像经过 A(1, 3)、B(4, 9)，请先列出两个方程，再求函数表达式，并说明每一步依据。'
      : '同断点变式题：已知一次函数 y = 3x - 2，求 x = 4 时 y 的值，并写出代入位置和计算过程。'),
    targetBreakpoint: breakpoint,
    knowledgePoint: aligned.knowledgePoint || knowledgePoint,
    answerHidden: true,
    prompt: '先独立完成，再对照订正卡检查是否又在同一断点出错。'
  }
}

export function summarizeDialogue(messages = []) {
  const studentMessages = toArray(messages).filter((item) => item.role === 'student')
  if (!studentMessages.length) return '学生尚未形成完整追问记录。'
  return studentMessages
    .slice(-3)
    .map((item, index) => `${index + 1}. ${item.content}`)
    .join('\n')
}

export function buildCorrectionCardPayload(input = {}) {
  const analysis = input.analysis || {}
  const diagnosis = input.diagnosis || buildDiagnosis(input)
  const question = input.question || analysis.questionText || input.card?.question || ''
  const originalThinking = pickOriginalThinking({
    question,
    studentAnswer: input.studentAnswer,
    studentReply: input.studentReply,
    analysisStudentWork: analysis.studentWorkText,
    cardOriginalThinking: input.card?.originalThinking
  })
  const base = buildCorrectionCard({
    question,
    studentAnswer: originalThinking,
    knowledgePoint: analysis.knowledgePoint || input.card?.knowledgePoint
  })
  const nextReviewAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().slice(0, 10)
  const variant = buildVariantQuestion({
    ...input,
    breakpoint: diagnosis.mainBreakpoint,
    knowledgePoint: analysis.knowledgePoint || base.knowledgePoint
  })

  return {
    ...base,
    ...input.card,
    cardId: input.cardId || `card_${Date.now()}`,
    questionId: input.questionId || diagnosis.questionId,
    question: question || base.question,
    knowledgePoint: analysis.knowledgePoint || input.card?.knowledgePoint || base.knowledgePoint,
    errorTag: diagnosis.errorType || input.card?.errorTag || base.errorTag,
    errorReason: diagnosis.evidence || input.card?.errorReason || base.errorReason,
    originalThinking: originalThinking || base.originalThinking,
    correctionTip: analysis.correctionCard?.tip || pickDraftText({ question, value: input.card?.correctionTip }) || base.correctionTip,
    breakpoint: diagnosis.mainBreakpoint,
    secondaryBreakpoint: diagnosis.secondaryBreakpoint,
    dialogueSummary: summarizeDialogue(input.messages || input.dialogueHistory),
    correctThinking: input.correctThinking || analysis.correctionCard?.correctThinking || pickDraftText({ question, value: input.card?.correctThinking }) || base.correctThinking,
    studentSummary: input.studentSummary || input.summary || '',
    studentSummaryPrompt: '请用自己的话写下：这道题错在什么环节，下次先检查哪一步？',
    nextReviewAt,
    variantQuestion: variant.variantQuestion,
    targetBreakpoint: variant.targetBreakpoint
  }
}

export function buildProfile(cards = []) {
  const source = cards.length ? cards : DEFAULT_CARDS
  return {
    userId: 'demo_user',
    sampleSize: source.length,
    topBreakpoints: countBy(source, (card) => card.breakpoint || pickBreakpoint(card.errorTag)).slice(0, 5),
    topKnowledgePoints: countBy(source, (card) => card.knowledgePoint).slice(0, 5),
    topErrors: countBy(source, (card) => card.errorTag).slice(0, 5),
    hintDependency: [
      { name: 'L1方向提示', count: Math.max(1, Math.ceil(source.length * 0.5)) },
      { name: 'L2关键问题', count: Math.max(1, Math.floor(source.length * 0.35)) },
      { name: 'L3半步示范', count: Math.max(0, Math.floor(source.length * 0.15)) }
    ],
    recentProgress: source.length >= 3
      ? '最近订正记录增多，建议关注高频断点是否重复出现。'
      : '已形成基础订正记录，可以继续积累同类错因。'
  }
}

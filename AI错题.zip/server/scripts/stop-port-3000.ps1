$connections = Get-NetTCPConnection -LocalPort 3000 -ErrorAction SilentlyContinue |
  Where-Object { $_.State -eq 'Listen' }

if (-not $connections) {
  Write-Host "No process is listening on port 3000."
  exit 0
}

foreach ($connection in $connections) {
  $processId = $connection.OwningProcess
  $process = Get-Process -Id $processId -ErrorAction SilentlyContinue
  if ($process) {
    Write-Host "Stopping process $($process.ProcessName) ($processId) on port 3000..."
    Stop-Process -Id $processId -Force
  }
}
